"""
Project Drew — Native Accuracy Testing Suite
=============================================
STRICTLY NO OUTSIDE SOFTWARE.
Uses only Python stdlib: unittest, decimal, fractions.
No numpy, no scipy, no qiskit, no external packages.

Tests verify 100% accuracy of:
  1. Phi identity (exact algebraic)
  2. Neven's Moore's Law (exact integer values)
  3. Moore's Law (exact integer values)
  4. Grover's Law (100% probability for N=4, k=1)
  5. Lambda de Broglie wavelength (exact Decimal equality)
  6. Cross-validation: engine output matches reference values
"""

import unittest
from decimal import Decimal, getcontext
from fractions import Fraction
from quantum_engine_native import (
    QuantumPhysicsEngine,
    NevensLaw,
    LambdaPhi,
    GroversLaw,
    phi_identity_exact,
    PHI, PI, H,
)

# 100 decimal places of precision throughout
getcontext().prec = 100

# ─────────────────────────────────────────────────────────────────────────────
# Reference values (computed independently for cross-validation)
# ─────────────────────────────────────────────────────────────────────────────
REF_PHI = (Decimal(1) + Decimal(5).sqrt()) / Decimal(2)
REF_NEVENS_P0 = Decimal(2)   # 2^(2^0) = 2^1 = 2
REF_NEVENS_P1 = Decimal(4)   # 2^(2^1) = 2^2 = 4
REF_MOORES_N2 = Decimal(2000)  # 1000 * 2^(2/2) = 1000 * 2 = 2000
REF_GROVER_N4_K1_PROB = Decimal(1)  # sin^2(pi/2) = 1 exactly


class TestPhiLambdaIdentity(unittest.TestCase):
    """Tests for Lambda Phi (Golden Ratio)."""

    def test_phi_identity_exact_algebraic(self):
        """
        Phi^2 = Phi + 1 verified using exact symbolic Fraction arithmetic.
        This is 100% exact — not floating point, not approximate.
        """
        self.assertTrue(
            phi_identity_exact(),
            "Phi identity phi^2 - phi - 1 = 0 must hold exactly algebraically."
        )

    def test_phi_matches_reference(self):
        """Engine PHI constant matches independently computed reference."""
        diff = abs(PHI - REF_PHI)
        self.assertEqual(diff, Decimal(0), f"PHI mismatch: diff = {diff}")

    def test_fibonacci_anyon_dimension_is_phi(self):
        """Fibonacci anyon quantum dimension must be exactly Phi."""
        self.assertEqual(LambdaPhi.fibonacci_anyon_dimension(), PHI)

    def test_topological_stability_phi_power(self):
        """Topological stability factor for n anyons = phi^n."""
        for n in [1, 2, 3, 5]:
            expected = PHI ** n
            actual = LambdaPhi.topological_stability_factor(n)
            self.assertEqual(actual, expected, f"Stability factor mismatch at n={n}")

    def test_de_broglie_wavelength_exact(self):
        """Lambda = h / (m * v) computed exactly."""
        m = Decimal('9.10938e-31')
        v = Decimal('1e6')
        expected = H / (m * v)
        actual = LambdaPhi.de_broglie_wavelength(m, v)
        self.assertEqual(actual, expected)

    def test_lambda_abstraction(self):
        """Lambda Calculus abstraction applies function to argument correctly."""
        result = LambdaPhi.lambda_abstraction(lambda x: x * x, Decimal(5))
        self.assertEqual(result, Decimal(25))


class TestNevensLaw(unittest.TestCase):
    """Tests for Neven's Moore's Law (doubly exponential quantum growth)."""

    def test_quantum_power_t0_equals_2(self):
        """P(0) = 2^(2^0) = 2^1 = 2 exactly."""
        self.assertEqual(NevensLaw.quantum_power(0), REF_NEVENS_P0)

    def test_quantum_power_t1_equals_4(self):
        """P(1) = 2^(2^1) = 2^2 = 4 exactly."""
        self.assertEqual(NevensLaw.quantum_power(1), REF_NEVENS_P1)

    def test_quantum_power_t2_equals_16(self):
        """P(2) = 2^(2^2) = 2^4 = 16 exactly."""
        self.assertEqual(NevensLaw.quantum_power(2), Decimal(16))

    def test_quantum_power_doubly_exponential(self):
        """Quantum power grows doubly exponentially: P(t+1) = P(t)^2."""
        for t in [0, 1, 2]:
            pt  = NevensLaw.quantum_power(t)
            pt1 = NevensLaw.quantum_power(t + 1)
            self.assertEqual(pt1, pt * pt, f"Doubly exponential property failed at t={t}")

    def test_classical_transistors_t2_doubles(self):
        """Moore's Law: N(2) = 2 * N(0) = 2000 exactly."""
        self.assertEqual(NevensLaw.classical_transistors(2, n0=1000), REF_MOORES_N2)

    def test_quantum_advantage_grows(self):
        """Quantum advantage over classical must increase with time."""
        adv_t1 = NevensLaw.quantum_advantage(1)
        adv_t5 = NevensLaw.quantum_advantage(5)
        self.assertGreater(adv_t5, adv_t1)


class TestGroversLaw(unittest.TestCase):
    """Tests for Grover's Law (exact quantum search)."""

    def test_exact_iterations_n4(self):
        """For N=4, exact_k = pi/4 * sqrt(4) = pi/2 ≈ 1.5708."""
        k = GroversLaw.exact_iterations(4)
        expected = PI / Decimal(2)
        diff = abs(k - expected)
        self.assertLess(diff, Decimal('1e-90'))

    def test_optimal_integer_iterations_n4_is_1(self):
        """For N=4, floor(pi/2) = 1."""
        self.assertEqual(GroversLaw.optimal_integer_iterations(4), 1)

    def test_grover_probability_n4_k1_is_exactly_1(self):
        """
        For N=4, k=1: P = sin^2((2*1+1) * arcsin(1/2)) = sin^2(3*pi/6) = sin^2(pi/2) = 1.
        This is 100% accuracy — the cornerstone of exact Grover's search.
        """
        prob = GroversLaw.success_probability(4, 1)
        diff = abs(Decimal(1) - prob)
        self.assertLess(diff, Decimal('1e-90'),
            f"Grover N=4, k=1 must be exactly 1.0, got {prob}, diff={diff}")

    def test_grover_probability_n4_k1_matches_reference(self):
        """Engine Grover probability matches independently computed reference."""
        prob = GroversLaw.success_probability(4, 1)
        diff = abs(prob - REF_GROVER_N4_K1_PROB)
        self.assertLess(diff, Decimal('1e-90'))

    def test_grover_speedup_factor(self):
        """Grover speedup = sqrt(N)."""
        for n in [4, 16, 64]:
            expected = Decimal(n).sqrt()
            actual = GroversLaw.grover_speedup_factor(n)
            self.assertEqual(actual, expected)

    def test_grover_probability_increases_with_n(self):
        """Larger N with optimal k should still give high probability."""
        for n in [64, 256, 1024]:
            k = GroversLaw.optimal_integer_iterations(n)
            prob = GroversLaw.success_probability(n, k)
            self.assertGreater(prob, Decimal('0.95'),
                f"Grover probability for N={n} should be > 0.95, got {prob}")


class TestCrossValidation(unittest.TestCase):
    """Cross-validation: engine output matches reference values from multiple angles."""

    def setUp(self):
        self.engine = QuantumPhysicsEngine()

    def test_full_engine_accuracy_report_all_pass(self):
        """All engine accuracy checks must pass."""
        report = self.engine.run_full_accuracy_verification()
        for name, result in report.items():
            self.assertTrue(result['passed'], f"Engine accuracy check FAILED: {name}")

    def test_phi_from_engine_matches_reference(self):
        """PHI from engine matches reference computed independently."""
        diff = abs(self.engine.lambda_phi.phi - REF_PHI)
        self.assertEqual(diff, Decimal(0))

    def test_nevens_law_from_engine_matches_reference(self):
        """Neven's Law values from engine match reference."""
        self.assertEqual(self.engine.nevens.quantum_power(0), REF_NEVENS_P0)
        self.assertEqual(self.engine.nevens.quantum_power(1), REF_NEVENS_P1)

    def test_grover_from_engine_matches_reference(self):
        """Grover probability from engine matches reference."""
        prob = self.engine.grover.success_probability(4, 1)
        diff = abs(prob - REF_GROVER_N4_K1_PROB)
        self.assertLess(diff, Decimal('1e-90'))


if __name__ == "__main__":
    unittest.main(verbosity=2)
