import SwiftUI

// MARK: - Terminal State (Observable)
@MainActor
final class TerminalState: ObservableObject {
    @Published var lines: [String] = []
    @Published var currentLine: String = ""
    @Published var inputText: String = ""
    @Published var isWaitingForInput: Bool = false
    @Published var cursorVisible: Bool = true

    private var machine: AppleIIMachine?
    private var cursorTimer: Timer?
    private var partialLine: String = ""
    private var lastOutputHadNewline: Bool = true

    func setup(machine: AppleIIMachine) {
        self.machine = machine

        machine.onOutput = { [weak self] text in
            Task { @MainActor in
                self?.appendOutput(text)
            }
        }

        // Start cursor blink
        cursorTimer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { [weak self] _ in
            Task { @MainActor in
                self?.cursorVisible.toggle()
            }
        }
    }

    func appendOutput(_ text: String) {
        var pending = partialLine + text
        partialLine = ""

        // Process character by character
        var lineBuffer = currentLine
        for ch in pending {
            switch ch {
            case "\r", "\n":
                lines.append(lineBuffer)
                lineBuffer = ""
                if lines.count > 500 { lines.removeFirst(lines.count - 500) }
            case "\u{08}":  // backspace
                if !lineBuffer.isEmpty { lineBuffer.removeLast() }
            default:
                lineBuffer.append(ch)
            }
        }
        currentLine = lineBuffer
    }

    func submitInput() {
        let text = inputText
        inputText = ""

        // Echo to screen
        appendOutput(text + "\r")

        // Send to machine
        machine?.sendInput(text)
    }

    func sendKey(_ ascii: UInt8) {
        machine?.sendCharacter(ascii)
    }

    func clear() {
        lines.removeAll()
        currentLine = ""
        partialLine = ""
    }

    func restart() {
        clear()
        lines.append("*** RESTART ***")
        lines.append("")
        machine?.restart()
    }
}

// MARK: - Apple II Color Theme
enum AppleTheme {
    // Classic Apple II green phosphor
    static let background = Color(red: 0.04, green: 0.08, blue: 0.04)
    static let text = Color(red: 0.20, green: 0.95, blue: 0.20)
    static let dimText = Color(red: 0.10, green: 0.55, blue: 0.10)
    static let inputText = Color(red: 0.60, green: 1.00, blue: 0.60)
    static let cursor = Color(red: 0.20, green: 0.95, blue: 0.20)
    static let scanline = Color.black.opacity(0.08)
    static let border = Color(red: 0.10, green: 0.30, blue: 0.10)
}

// MARK: - Scanline Effect
struct ScanlineView: View {
    var body: some View {
        GeometryReader { geo in
            Canvas { ctx, size in
                let lineHeight: CGFloat = 3
                var y: CGFloat = 0
                while y < size.height {
                    ctx.fill(
                        Path(CGRect(x: 0, y: y, width: size.width, height: 1)),
                        with: .color(AppleTheme.scanline)
                    )
                    y += lineHeight
                }
            }
        }
        .allowsHitTesting(false)
    }
}

// MARK: - CRT Vignette
struct VignetteView: View {
    var body: some View {
        GeometryReader { _ in
            RadialGradient(
                gradient: Gradient(colors: [
                    Color.clear,
                    Color.black.opacity(0.4)
                ]),
                center: .center,
                startRadius: 100,
                endRadius: 400
            )
        }
        .allowsHitTesting(false)
    }
}

// MARK: - Terminal View
struct TerminalView: View {
    @StateObject private var state = TerminalState()
    @State private var machine: AppleIIMachine?
    @FocusState private var inputFocused: Bool

    let fontName = "Menlo"
    let fontSize: CGFloat = 14

    var body: some View {
        ZStack {
            // CRT background
            AppleTheme.background
                .ignoresSafeArea()

            VStack(spacing: 0) {
                // Header bar
                headerBar

                // Terminal output area
                ScrollViewReader { proxy in
                    ScrollView {
                        VStack(alignment: .leading, spacing: 0) {
                            // Historical lines
                            ForEach(Array(state.lines.enumerated()), id: \.offset) { _, line in
                                Text(line.isEmpty ? " " : line)
                                    .font(.custom(fontName, size: fontSize))
                                    .foregroundColor(AppleTheme.text)
                                    .frame(maxWidth: .infinity, alignment: .leading)
                            }
                            // Current line + cursor
                            HStack(spacing: 0) {
                                Text(state.currentLine.isEmpty ? "" : state.currentLine)
                                    .font(.custom(fontName, size: fontSize))
                                    .foregroundColor(AppleTheme.text)
                                // Blinking cursor block
                                Rectangle()
                                    .fill(state.cursorVisible ? AppleTheme.cursor : Color.clear)
                                    .frame(width: 9, height: fontSize + 2)
                            }
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .id("bottom")
                        }
                        .padding(.horizontal, 12)
                        .padding(.vertical, 8)
                    }
                    .onChange(of: state.lines.count) { _ in
                        withAnimation(.easeOut(duration: 0.1)) {
                            proxy.scrollTo("bottom", anchor: .bottom)
                        }
                    }
                    .onChange(of: state.currentLine) { _ in
                        withAnimation(.easeOut(duration: 0.1)) {
                            proxy.scrollTo("bottom", anchor: .bottom)
                        }
                    }
                }

                // Input bar
                inputBar
            }

            // Overlay effects
            ScanlineView()
            VignetteView()
        }
        .onAppear {
            startMachine()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                inputFocused = true
            }
        }
    }

    // MARK: - Header
    var headerBar: some View {
        HStack {
            Text("APPLE II — APPLESOFT BASIC")
                .font(.custom(fontName, size: 11))
                .foregroundColor(AppleTheme.dimText)
            Spacer()
            Button(action: { state.restart() }) {
                Text("RESET")
                    .font(.custom(fontName, size: 11))
                    .foregroundColor(AppleTheme.dimText)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 3)
                    .overlay(
                        RoundedRectangle(cornerRadius: 3)
                            .stroke(AppleTheme.border, lineWidth: 1)
                    )
            }
            .buttonStyle(PlainButtonStyle())
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 6)
        .background(Color.black.opacity(0.4))
        .overlay(
            Rectangle()
                .frame(height: 1)
                .foregroundColor(AppleTheme.border),
            alignment: .bottom
        )
    }

    // MARK: - Input Bar
    var inputBar: some View {
        HStack(spacing: 0) {
            Text("]")
                .font(.custom(fontName, size: fontSize))
                .foregroundColor(AppleTheme.dimText)
                .padding(.leading, 12)

            TextField("", text: $state.inputText)
                .font(.custom(fontName, size: fontSize))
                .foregroundColor(AppleTheme.inputText)
                .accentColor(AppleTheme.cursor)
                .tint(AppleTheme.cursor)
                .autocorrectionDisabled(true)
                .autocapitalization(.allCharacters)
                .keyboardType(.asciiCapable)
                .focused($inputFocused)
                .onSubmit {
                    state.submitInput()
                    inputFocused = true
                }
                .padding(.horizontal, 8)
                .padding(.vertical, 10)
                .submitLabel(.done)

            Button(action: {
                state.submitInput()
                inputFocused = true
            }) {
                Image(systemName: "return")
                    .foregroundColor(AppleTheme.dimText)
                    .padding(.trailing, 12)
            }
            .buttonStyle(PlainButtonStyle())
        }
        .background(Color.black.opacity(0.5))
        .overlay(
            Rectangle()
                .frame(height: 1)
                .foregroundColor(AppleTheme.border),
            alignment: .top
        )
    }

    // MARK: - Machine Startup
    private func startMachine() {
        let m = AppleIIMachine()
        self.machine = m
        state.setup(machine: m)

        // Show boot message before starting
        state.appendOutput("""

        APPLE II COMPUTER — APPLESOFT BASIC
        COPYRIGHT 1976 APPLE COMPUTER INC.
        64K RAM SYSTEM   38911 BASIC BYTES FREE

        ]
        """)

        m.start()
    }
}

// MARK: - Main App
@main
struct AppleSoftBasicApp: App {
    var body: some Scene {
        WindowGroup {
            TerminalView()
                .preferredColorScheme(.dark)
        }
    }
}
