# Applesoft BASIC — iOS App

A pure Swift iOS app that runs the original Applesoft BASIC interpreter (Apple Computer Inc., 1976) via a full 6502 CPU emulator, with no external dependencies.

## What this is

This app emulates the complete Apple II hardware environment and runs the Applesoft BASIC interpreter — the same code described in `Apple_1776596775927.s`. It includes:

- **Full MOS 6502 CPU emulator** — all official opcodes, accurate flags and addressing modes
- **64KB memory map** — RAM, ROM region protection, soft-switches
- **Apple II I/O emulation** — keyboard ($C000), display output, monitor ROM stubs (COUT, RDKEY, GETLN, etc.)
- **Applesoft BASIC ROM** — the 16KB interpreter loaded at $D000–$FFFF
- **Apple II green-phosphor CRT UI** — scanlines, vignette, blinking cursor, monospace font

## Project Structure

```
AppleSoftBasic/
├── AppleSoftBasic.xcodeproj/          ← Open this in Xcode
│   ├── project.pbxproj
│   └── xcshareddata/xcschemes/
│       └── AppleSoftBasic.xcscheme
└── AppleSoftBasic/
    ├── Sources/
    │   ├── CPU6502.swift              ← Full MOS 6502 CPU emulator
    │   ├── Memory.swift               ← 64KB memory with I/O hooks
    │   ├── AppleSoftROM.swift         ← Applesoft BASIC ROM data
    │   ├── AppleIIMachine.swift       ← Apple II machine wiring
    │   └── TerminalView.swift         ← SwiftUI CRT terminal UI + App entry
    └── Resources/
        └── Info.plist
```

## How to Build and Run

### Requirements
- macOS 13+ with Xcode 15+
- iOS 16+ device or simulator

### Steps
1. Open `AppleSoftBasic.xcodeproj` in Xcode
2. Select your target device (iPhone/iPad/Simulator)
3. Press **⌘R** to build and run
4. The Applesoft BASIC prompt `]` will appear
5. Type BASIC commands and press Return

## Usage

Once running, you'll see the classic Apple II boot screen:

```
APPLE II COMPUTER — APPLESOFT BASIC
COPYRIGHT 1976 APPLE COMPUTER INC.
64K RAM SYSTEM   38911 BASIC BYTES FREE

]
```

Type any Applesoft BASIC command at the `]` prompt:

```basic
] PRINT "HELLO, WORLD"
HELLO, WORLD

] 10 FOR I = 1 TO 10
] 20 PRINT I * I
] 30 NEXT I
] RUN
1
4
9
16
25
36
49
64
81
100

] LIST
10  FOR I = 1 TO 10
20  PRINT I * I
30  NEXT I
```

## Technical Notes

### CPU Emulator (`CPU6502.swift`)
- Implements all 151 official 6502 opcodes
- Accurate status flag handling (N, V, B, D, I, Z, C)
- Correct page-crossing cycle penalties
- Stack operations at $0100–$01FF
- BCD mode flag tracked (Applesoft BASIC uses it)

### Memory Map (`Memory.swift`)
```
$0000–$00FF  Zero Page (BASIC variables, pointers)
$0100–$01FF  Stack
$0200–$02FF  Input buffer (GETLN)
$0800–$CFFF  RAM (BASIC program + variables)
$C000        Keyboard data (bit 7 = key ready)
$C010        Keyboard strobe (read to clear)
$D000–$FFFF  Applesoft BASIC ROM (16KB)
$FDED        COUT stub (character output)
$FD0C        RDKEY stub (keyboard input)
$FFFC–$FFFD  Reset vector → $D000
```

### ROM Source
The Applesoft BASIC ROM corresponds to the assembly source in `Apple_1776596775927.s` — REALIO=4 (Apple configuration), ROMSW=1, RORSW=1, compiled for the Apple II with the standard monitor ROM interface.

## Architecture

The app runs the 6502 CPU on a background thread at approximately 1MHz (authentic Apple II speed). Character output is routed via memory write intercept at $D012, and keyboard input is delivered via the $C000/$C010 soft-switch pair. The SwiftUI layer bridges asynchronously to the CPU thread using `@MainActor` and `DispatchQueue.main`.
