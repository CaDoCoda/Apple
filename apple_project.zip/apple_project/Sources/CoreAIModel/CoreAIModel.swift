import CoreML
import Vision
import UIKit // For UIImage, will need to be adapted for non-UI environments

@available(macOS 10.15, iOS 13.0, tvOS 13.0, watchOS 6.0, *) // Adjust availability as needed
public class CoreAIModel {
    public let model: MLModel

    /// Creates a CoreAIModel instance with the specified URL to the .mlmodelc file.
    /// - Parameter modelURL: The URL to the compiled .mlmodelc file.
    /// - Throws: An error if the model cannot be loaded.
    public init(modelURL: URL) throws {
        self.model = try MLModel(contentsOf: modelURL)
    }

    /// Convenience initializer to load the model from the bundled CoreAI.mlpackage.
    /// - Throws: An error if the model cannot be found or loaded.
    public convenience init() throws {
        guard let modelURL = Bundle.main.url(forResource: "CoreAI", withExtension: "mlpackage") else {
            fatalError("Failed to find CoreAI.mlpackage in the app bundle.")
        }
        try self.init(modelURL: modelURL)
    }

    /// Makes a prediction using the CoreML model.
    /// - Parameter image: The input image as a CVPixelBuffer.
    /// - Returns: The prediction output as an MLFeatureProvider.
    /// - Throws: An error if prediction fails.
    public func predict(image: CVPixelBuffer) throws -> MLFeatureProvider {
        let input = CoreAIInput(input_1: image)
        let output = try model.prediction(from: input)
        return output
    }
}

/// Input wrapper for the CoreAI model.
@available(macOS 10.15, iOS 13.0, tvOS 13.0, watchOS 6.0, *)
class CoreAIInput: MLFeatureProvider {
    var input_1: CVPixelBuffer

    var featureNames: Set<String> { return ["input_1"] }

    func featureValue(for featureName: String) -> MLFeatureValue? {
        if featureName == "input_1" {
            return MLFeatureValue(pixelBuffer: input_1)
        }
        return nil
    }

    init(input_1: CVPixelBuffer) {
        self.input_1 = input_1
    }
}

/// Output wrapper for the CoreAI model.
@available(macOS 10.15, iOS 13.0, tvOS 13.0, watchOS 6.0, *)
class CoreAIOutput: MLFeatureProvider {
    let featureProvider: MLFeatureProvider

    lazy var var_24: MLMultiArray = {
        guard let multiArray = self.featureProvider.featureValue(for: "var_24")?.multiArrayValue else {
            fatalError("Expected MLMultiArray for var_24")
        }
        return multiArray
    }()

    var featureNames: Set<String> { return ["var_24"] }

    func featureValue(for featureName: String) -> MLFeatureValue? {
        return featureProvider.featureValue(for: featureName)
    }

    init(features: MLFeatureProvider) {
        self.featureProvider = features
    }
}
