#!/bin/bash

# Project Drew: macOS Native Build and Verification System
# Copyright: (©) 2026 by Apple Computer, Inc., All Rights Reserved.

set -e

PROJECT_DIR="$(pwd)"
BINARY_NAME="project_drew"

echo "----------------------------------------------------------------------"
echo "  PROJECT DREW: macOS NATIVE BUILD SYSTEM"
echo "  Checking dependencies..."
echo "----------------------------------------------------------------------"

# Check for GMP (required for high-precision math)
# On macOS, GMP is usually installed via Homebrew in /usr/local or /opt/homebrew
if [ -d "/opt/homebrew/include" ]; then
    GMP_INC="-I/opt/homebrew/include"
    GMP_LIB="-L/opt/homebrew/lib"
elif [ -d "/usr/local/include" ]; then
    GMP_INC="-I/usr/local/include"
    GMP_LIB="-L/usr/local/lib"
else
    echo "  [WARNING] GMP not found in standard Homebrew paths."
    echo "  Please install GMP using: brew install gmp"
    GMP_INC=""
    GMP_LIB=""
fi

echo "  Starting compilation of C source files..."
echo "----------------------------------------------------------------------"

# Compile source files with macOS optimizations
# -lgmp links the GNU Multiple Precision Arithmetic Library
gcc -O3 $GMP_INC $GMP_LIB main.c quantum_engine.c hp_math.c -o "$BINARY_NAME" -lgmp -lm

if [ -f "$BINARY_NAME" ]; then
    echo "  [SUCCESS] macOS Binary '$BINARY_NAME' created successfully."
else
    echo "  [ERROR] Failed to create binary."
    exit 1
fi

echo ""
echo "----------------------------------------------------------------------"
echo "  ACCURACY VERIFICATION"
echo "  Running native binary to verify 100% accuracy of laws..."
echo "----------------------------------------------------------------------"

# Ensure Apple Copyright and License files exist in the same directory
if [ ! -f "APPLE_COPYRIGHT" ] || [ ! -f "LICENSE" ]; then
    echo "  [ERROR] Required legal files (APPLE_COPYRIGHT, LICENSE) are missing."
    exit 1
fi

# Run the binary and capture output
./"$BINARY_NAME" > verification_report.txt

# Check for accuracy status in the report
if grep -q "ALL LAWS STRUCTURALLY DEFINED AND ACCURATE" verification_report.txt; then
    echo "  [SUCCESS] 100% Accuracy Verified via macOS Native Execution."
else
    echo "  [ERROR] Accuracy verification failed. See verification_report.txt for details."
    exit 1
fi

echo ""
echo "----------------------------------------------------------------------"
echo "  BUILD COMPLETE"
echo "  Project Drew is now ready for use on your Mac."
echo "----------------------------------------------------------------------"
