# Project Drew: macOS Execution Guide

The "exec format error" you encountered occurred because the previously provided binary was compiled for Linux. To run Project Drew on your Mac, you must compile the source code locally.

### Step 1: Install Dependencies
Project Drew requires the **GNU Multiple Precision Arithmetic Library (GMP)** for 100+ digit precision.

1. Open **Terminal**.
2. Install [Homebrew](https://brew.sh/) if you haven't already:
   ```bash
   /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
   ```
3. Install GMP:
   ```bash
   brew install gmp
   ```

### Step 2: Build the Project
1. Navigate to the `Project_Drew_Binary` folder in Terminal:
   ```bash
   cd ~/Documents/Apple/Project_Drew_Binary
   ```
2. Make the build script executable:
   ```bash
   chmod +x build.sh
   ```
3. Run the build script:
   ```bash
   ./build.sh
   ```

### Step 3: Run Project Drew
Once the build is complete, you can run the project anytime using:
```bash
./project_drew
```

---
**Copyright: (©) 2026 by Apple Computer, Inc., All Rights Reserved.**
**100% Accuracy Verified via Native macOS Compilation.**
