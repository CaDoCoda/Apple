import Foundation

// MARK: - 6502 CPU Emulator

final class CPU6502 {

    // MARK: Registers
    var PC: UInt16 = 0x0000
    var SP: UInt8  = 0xFF
    var A:  UInt8  = 0x00
    var X:  UInt8  = 0x00
    var Y:  UInt8  = 0x00

    // MARK: Flags
    var flagC: Bool = false  // Carry
    var flagZ: Bool = false  // Zero
    var flagI: Bool = true   // Interrupt Disable
    var flagD: Bool = false  // Decimal
    var flagB: Bool = false  // Break
    var flagV: Bool = false  // Overflow
    var flagN: Bool = false  // Negative

    var P: UInt8 {
        get {
            var p: UInt8 = 0x20
            if flagC { p |= 0x01 }
            if flagZ { p |= 0x02 }
            if flagI { p |= 0x04 }
            if flagD { p |= 0x08 }
            if flagB { p |= 0x10 }
            if flagV { p |= 0x40 }
            if flagN { p |= 0x80 }
            return p
        }
        set {
            flagC = (newValue & 0x01) != 0
            flagZ = (newValue & 0x02) != 0
            flagI = (newValue & 0x04) != 0
            flagD = (newValue & 0x08) != 0
            flagB = (newValue & 0x10) != 0
            flagV = (newValue & 0x40) != 0
            flagN = (newValue & 0x80) != 0
        }
    }

    // MARK: Memory
    var memory: Memory

    var cycles: UInt64 = 0
    var running: Bool = false
    var halted: Bool = false

    init(memory: Memory) {
        self.memory = memory
    }

    func reset() {
        let lo = UInt16(memory.read(0xFFFC))
        let hi = UInt16(memory.read(0xFFFD))
        PC = (hi << 8) | lo
        SP = 0xFF
        A = 0; X = 0; Y = 0
        flagI = true
        flagD = false
        flagC = false
        flagZ = false
        flagV = false
        flagN = false
        cycles = 0
        halted = false
    }

    // MARK: - Stack
    @inline(__always) func pushByte(_ val: UInt8) {
        memory.write(0x0100 &+ UInt16(SP), val)
        SP &-= 1
    }

    @inline(__always) func pullByte() -> UInt8 {
        SP &+= 1
        return memory.read(0x0100 &+ UInt16(SP))
    }

    @inline(__always) func pushWord(_ val: UInt16) {
        pushByte(UInt8((val >> 8) & 0xFF))
        pushByte(UInt8(val & 0xFF))
    }

    @inline(__always) func pullWord() -> UInt16 {
        let lo = UInt16(pullByte())
        let hi = UInt16(pullByte())
        return (hi << 8) | lo
    }

    // MARK: - Flag helpers
    @inline(__always) func setNZ(_ val: UInt8) {
        flagN = (val & 0x80) != 0
        flagZ = val == 0
    }

    // MARK: - Address Modes
    @inline(__always) func fetchByte() -> UInt8 {
        let v = memory.read(PC); PC &+= 1; return v
    }

    @inline(__always) func fetchWord() -> UInt16 {
        let lo = UInt16(fetchByte())
        let hi = UInt16(fetchByte())
        return (hi << 8) | lo
    }

    @inline(__always) func addrZP() -> UInt16 { return UInt16(fetchByte()) }
    @inline(__always) func addrZPX() -> UInt16 { return UInt16((fetchByte() &+ X) & 0xFF) }
    @inline(__always) func addrZPY() -> UInt16 { return UInt16((fetchByte() &+ Y) & 0xFF) }

    @inline(__always) func addrABS() -> UInt16 { return fetchWord() }

    @inline(__always) func addrABSX(penalty: inout Int) -> UInt16 {
        let base = fetchWord()
        let addr = base &+ UInt16(X)
        if (base & 0xFF00) != (addr & 0xFF00) { penalty = 1 }
        return addr
    }

    @inline(__always) func addrABSY(penalty: inout Int) -> UInt16 {
        let base = fetchWord()
        let addr = base &+ UInt16(Y)
        if (base & 0xFF00) != (addr & 0xFF00) { penalty = 1 }
        return addr
    }

    @inline(__always) func addrINDX() -> UInt16 {
        let ptr = (fetchByte() &+ X) & 0xFF
        let lo = UInt16(memory.read(UInt16(ptr)))
        let hi = UInt16(memory.read(UInt16((ptr &+ 1) & 0xFF)))
        return (hi << 8) | lo
    }

    @inline(__always) func addrINDY(penalty: inout Int) -> UInt16 {
        let ptr = UInt16(fetchByte())
        let lo = UInt16(memory.read(ptr))
        let hi = UInt16(memory.read((ptr &+ 1) & 0xFF))
        let base = (hi << 8) | lo
        let addr = base &+ UInt16(Y)
        if (base & 0xFF00) != (addr & 0xFF00) { penalty = 1 }
        return addr
    }

    // MARK: - ADC / SBC helpers
    func adc(_ val: UInt8) {
        let a16 = UInt16(A) &+ UInt16(val) &+ (flagC ? 1 : 0)
        flagC = a16 > 0xFF
        let result = UInt8(a16 & 0xFF)
        flagV = ((A ^ result) & (val ^ result) & 0x80) != 0
        A = result
        setNZ(A)
    }

    func sbc(_ val: UInt8) {
        adc(val ^ 0xFF)
    }

    // MARK: - CMP helpers
    func cmp(_ a: UInt8, _ b: UInt8) {
        let r = a &- b
        flagC = a >= b
        setNZ(r)
    }

    // MARK: - Branch
    func branch(cond: Bool) {
        let offset = Int8(bitPattern: fetchByte())
        if cond {
            let old = PC
            PC = UInt16(bitPattern: Int16(bitPattern: PC) &+ Int16(offset))
            cycles += (old & 0xFF00 != PC & 0xFF00) ? 2 : 1
        }
    }

    // MARK: - Step one instruction
    @discardableResult
    func step() -> Int {
        guard !halted else { return 0 }
        let opcode = fetchByte()
        var extra = 0
        switch opcode {
        // BRK
        case 0x00:
            PC &+= 1
            pushWord(PC)
            flagB = true
            pushByte(P)
            flagI = true
            let lo = UInt16(memory.read(0xFFFE))
            let hi = UInt16(memory.read(0xFFFF))
            PC = (hi << 8) | lo
            cycles += 7

        // ORA (zp,X)
        case 0x01:
            let addr = addrINDX(); A |= memory.read(addr); setNZ(A); cycles += 6
        // ORA zp
        case 0x05:
            let addr = addrZP(); A |= memory.read(addr); setNZ(A); cycles += 3
        // ASL zp
        case 0x06:
            let addr = addrZP(); var v = memory.read(addr)
            flagC = (v & 0x80) != 0; v <<= 1; setNZ(v); memory.write(addr, v); cycles += 5
        // PHP
        case 0x08:
            pushByte(P | 0x30); cycles += 3
        // ORA #
        case 0x09:
            A |= fetchByte(); setNZ(A); cycles += 2
        // ASL A
        case 0x0A:
            flagC = (A & 0x80) != 0; A <<= 1; setNZ(A); cycles += 2
        // ORA abs
        case 0x0D:
            let addr = addrABS(); A |= memory.read(addr); setNZ(A); cycles += 4
        // ASL abs
        case 0x0E:
            let addr = addrABS(); var v = memory.read(addr)
            flagC = (v & 0x80) != 0; v <<= 1; setNZ(v); memory.write(addr, v); cycles += 6

        // BPL rel
        case 0x10: branch(cond: !flagN); cycles += 2
        // ORA (zp),Y
        case 0x11:
            let addr = addrINDY(penalty: &extra); A |= memory.read(addr); setNZ(A); cycles += 5 + extra
        // ORA zp,X
        case 0x15:
            let addr = addrZPX(); A |= memory.read(addr); setNZ(A); cycles += 4
        // ASL zp,X
        case 0x16:
            let addr = addrZPX(); var v = memory.read(addr)
            flagC = (v & 0x80) != 0; v <<= 1; setNZ(v); memory.write(addr, v); cycles += 6
        // CLC
        case 0x18: flagC = false; cycles += 2
        // ORA abs,Y
        case 0x19:
            let addr = addrABSY(penalty: &extra); A |= memory.read(addr); setNZ(A); cycles += 4 + extra
        // ORA abs,X
        case 0x1D:
            let addr = addrABSX(penalty: &extra); A |= memory.read(addr); setNZ(A); cycles += 4 + extra
        // ASL abs,X
        case 0x1E:
            let addr = addrABSX(penalty: &extra); var v = memory.read(addr)
            flagC = (v & 0x80) != 0; v <<= 1; setNZ(v); memory.write(addr, v); cycles += 7

        // JSR abs
        case 0x20:
            let addr = fetchWord(); pushWord(PC &- 1); PC = addr; cycles += 6
        // AND (zp,X)
        case 0x21:
            let addr = addrINDX(); A &= memory.read(addr); setNZ(A); cycles += 6
        // BIT zp
        case 0x24:
            let v = memory.read(addrZP()); flagZ = (A & v) == 0; flagN = (v & 0x80) != 0; flagV = (v & 0x40) != 0; cycles += 3
        // AND zp
        case 0x25:
            let addr = addrZP(); A &= memory.read(addr); setNZ(A); cycles += 3
        // ROL zp
        case 0x26:
            let addr = addrZP(); var v = memory.read(addr); let c = flagC
            flagC = (v & 0x80) != 0; v = (v << 1) | (c ? 1 : 0); setNZ(v); memory.write(addr, v); cycles += 5
        // PLP
        case 0x28:
            P = pullByte() & ~UInt8(0x10) | 0x20; cycles += 4
        // AND #
        case 0x29:
            A &= fetchByte(); setNZ(A); cycles += 2
        // ROL A
        case 0x2A:
            let c = flagC; flagC = (A & 0x80) != 0; A = (A << 1) | (c ? 1 : 0); setNZ(A); cycles += 2
        // BIT abs
        case 0x2C:
            let v = memory.read(addrABS()); flagZ = (A & v) == 0; flagN = (v & 0x80) != 0; flagV = (v & 0x40) != 0; cycles += 4
        // AND abs
        case 0x2D:
            let addr = addrABS(); A &= memory.read(addr); setNZ(A); cycles += 4
        // ROL abs
        case 0x2E:
            let addr = addrABS(); var v = memory.read(addr); let c = flagC
            flagC = (v & 0x80) != 0; v = (v << 1) | (c ? 1 : 0); setNZ(v); memory.write(addr, v); cycles += 6

        // BMI rel
        case 0x30: branch(cond: flagN); cycles += 2
        // AND (zp),Y
        case 0x31:
            let addr = addrINDY(penalty: &extra); A &= memory.read(addr); setNZ(A); cycles += 5 + extra
        // AND zp,X
        case 0x35:
            let addr = addrZPX(); A &= memory.read(addr); setNZ(A); cycles += 4
        // ROL zp,X
        case 0x36:
            let addr = addrZPX(); var v = memory.read(addr); let c = flagC
            flagC = (v & 0x80) != 0; v = (v << 1) | (c ? 1 : 0); setNZ(v); memory.write(addr, v); cycles += 6
        // SEC
        case 0x38: flagC = true; cycles += 2
        // AND abs,Y
        case 0x39:
            let addr = addrABSY(penalty: &extra); A &= memory.read(addr); setNZ(A); cycles += 4 + extra
        // AND abs,X
        case 0x3D:
            let addr = addrABSX(penalty: &extra); A &= memory.read(addr); setNZ(A); cycles += 4 + extra
        // ROL abs,X
        case 0x3E:
            let addr = addrABSX(penalty: &extra); var v = memory.read(addr); let c = flagC
            flagC = (v & 0x80) != 0; v = (v << 1) | (c ? 1 : 0); setNZ(v); memory.write(addr, v); cycles += 7

        // RTI
        case 0x40:
            P = pullByte() & ~UInt8(0x10) | 0x20; PC = pullWord(); cycles += 6
        // EOR (zp,X)
        case 0x41:
            let addr = addrINDX(); A ^= memory.read(addr); setNZ(A); cycles += 6
        // EOR zp
        case 0x45:
            let addr = addrZP(); A ^= memory.read(addr); setNZ(A); cycles += 3
        // LSR zp
        case 0x46:
            let addr = addrZP(); var v = memory.read(addr)
            flagC = (v & 0x01) != 0; v >>= 1; setNZ(v); memory.write(addr, v); cycles += 5
        // PHA
        case 0x48: pushByte(A); cycles += 3
        // EOR #
        case 0x49:
            A ^= fetchByte(); setNZ(A); cycles += 2
        // LSR A
        case 0x4A:
            flagC = (A & 0x01) != 0; A >>= 1; setNZ(A); cycles += 2
        // JMP abs
        case 0x4C:
            PC = fetchWord(); cycles += 3
        // EOR abs
        case 0x4D:
            let addr = addrABS(); A ^= memory.read(addr); setNZ(A); cycles += 4
        // LSR abs
        case 0x4E:
            let addr = addrABS(); var v = memory.read(addr)
            flagC = (v & 0x01) != 0; v >>= 1; setNZ(v); memory.write(addr, v); cycles += 6

        // BVC rel
        case 0x50: branch(cond: !flagV); cycles += 2
        // EOR (zp),Y
        case 0x51:
            let addr = addrINDY(penalty: &extra); A ^= memory.read(addr); setNZ(A); cycles += 5 + extra
        // EOR zp,X
        case 0x55:
            let addr = addrZPX(); A ^= memory.read(addr); setNZ(A); cycles += 4
        // LSR zp,X
        case 0x56:
            let addr = addrZPX(); var v = memory.read(addr)
            flagC = (v & 0x01) != 0; v >>= 1; setNZ(v); memory.write(addr, v); cycles += 6
        // CLI
        case 0x58: flagI = false; cycles += 2
        // EOR abs,Y
        case 0x59:
            let addr = addrABSY(penalty: &extra); A ^= memory.read(addr); setNZ(A); cycles += 4 + extra
        // EOR abs,X
        case 0x5D:
            let addr = addrABSX(penalty: &extra); A ^= memory.read(addr); setNZ(A); cycles += 4 + extra
        // LSR abs,X
        case 0x5E:
            let addr = addrABSX(penalty: &extra); var v = memory.read(addr)
            flagC = (v & 0x01) != 0; v >>= 1; setNZ(v); memory.write(addr, v); cycles += 7

        // RTS
        case 0x60:
            PC = pullWord() &+ 1; cycles += 6
        // ADC (zp,X)
        case 0x61:
            let addr = addrINDX(); adc(memory.read(addr)); cycles += 6
        // ADC zp
        case 0x65:
            let addr = addrZP(); adc(memory.read(addr)); cycles += 3
        // ROR zp
        case 0x66:
            let addr = addrZP(); var v = memory.read(addr); let c = flagC
            flagC = (v & 0x01) != 0; v = (v >> 1) | (c ? 0x80 : 0); setNZ(v); memory.write(addr, v); cycles += 5
        // PLA
        case 0x68: A = pullByte(); setNZ(A); cycles += 4
        // ADC #
        case 0x69:
            adc(fetchByte()); cycles += 2
        // ROR A
        case 0x6A:
            let c = flagC; flagC = (A & 0x01) != 0; A = (A >> 1) | (c ? 0x80 : 0); setNZ(A); cycles += 2
        // JMP (abs)
        case 0x6C:
            let ptr = fetchWord()
            let lo = UInt16(memory.read(ptr))
            let hi = UInt16(memory.read((ptr & 0xFF00) | ((ptr + 1) & 0x00FF)))
            PC = (hi << 8) | lo; cycles += 5
        // ADC abs
        case 0x6D:
            let addr = addrABS(); adc(memory.read(addr)); cycles += 4
        // ROR abs
        case 0x6E:
            let addr = addrABS(); var v = memory.read(addr); let c = flagC
            flagC = (v & 0x01) != 0; v = (v >> 1) | (c ? 0x80 : 0); setNZ(v); memory.write(addr, v); cycles += 6

        // BVS rel
        case 0x70: branch(cond: flagV); cycles += 2
        // ADC (zp),Y
        case 0x71:
            let addr = addrINDY(penalty: &extra); adc(memory.read(addr)); cycles += 5 + extra
        // ADC zp,X
        case 0x75:
            let addr = addrZPX(); adc(memory.read(addr)); cycles += 4
        // ROR zp,X
        case 0x76:
            let addr = addrZPX(); var v = memory.read(addr); let c = flagC
            flagC = (v & 0x01) != 0; v = (v >> 1) | (c ? 0x80 : 0); setNZ(v); memory.write(addr, v); cycles += 6
        // SEI
        case 0x78: flagI = true; cycles += 2
        // ADC abs,Y
        case 0x79:
            let addr = addrABSY(penalty: &extra); adc(memory.read(addr)); cycles += 4 + extra
        // ADC abs,X
        case 0x7D:
            let addr = addrABSX(penalty: &extra); adc(memory.read(addr)); cycles += 4 + extra
        // ROR abs,X
        case 0x7E:
            let addr = addrABSX(penalty: &extra); var v = memory.read(addr); let c = flagC
            flagC = (v & 0x01) != 0; v = (v >> 1) | (c ? 0x80 : 0); setNZ(v); memory.write(addr, v); cycles += 7

        // STA (zp,X)
        case 0x81: memory.write(addrINDX(), A); cycles += 6
        // STY zp
        case 0x84: memory.write(addrZP(), Y); cycles += 3
        // STA zp
        case 0x85: memory.write(addrZP(), A); cycles += 3
        // STX zp
        case 0x86: memory.write(addrZP(), X); cycles += 3
        // DEY
        case 0x88: Y &-= 1; setNZ(Y); cycles += 2
        // TXA
        case 0x8A: A = X; setNZ(A); cycles += 2
        // STY abs
        case 0x8C: memory.write(addrABS(), Y); cycles += 4
        // STA abs
        case 0x8D: memory.write(addrABS(), A); cycles += 4
        // STX abs
        case 0x8E: memory.write(addrABS(), X); cycles += 4

        // BCC rel
        case 0x90: branch(cond: !flagC); cycles += 2
        // STA (zp),Y
        case 0x91: memory.write(addrINDY(penalty: &extra), A); cycles += 6
        // STY zp,X
        case 0x94: memory.write(addrZPX(), Y); cycles += 4
        // STA zp,X
        case 0x95: memory.write(addrZPX(), A); cycles += 4
        // STX zp,Y
        case 0x96: memory.write(addrZPY(), X); cycles += 4
        // TYA
        case 0x98: A = Y; setNZ(A); cycles += 2
        // STA abs,Y
        case 0x99: memory.write(addrABSY(penalty: &extra), A); cycles += 5
        // TXS
        case 0x9A: SP = X; cycles += 2
        // STA abs,X
        case 0x9D: memory.write(addrABSX(penalty: &extra), A); cycles += 5

        // LDY #
        case 0xA0: Y = fetchByte(); setNZ(Y); cycles += 2
        // LDA (zp,X)
        case 0xA1: let addr = addrINDX(); A = memory.read(addr); setNZ(A); cycles += 6
        // LDX #
        case 0xA2: X = fetchByte(); setNZ(X); cycles += 2
        // LDY zp
        case 0xA4: Y = memory.read(addrZP()); setNZ(Y); cycles += 3
        // LDA zp
        case 0xA5: A = memory.read(addrZP()); setNZ(A); cycles += 3
        // LDX zp
        case 0xA6: X = memory.read(addrZP()); setNZ(X); cycles += 3
        // TAY
        case 0xA8: Y = A; setNZ(Y); cycles += 2
        // LDA #
        case 0xA9: A = fetchByte(); setNZ(A); cycles += 2
        // TAX
        case 0xAA: X = A; setNZ(X); cycles += 2
        // LDY abs
        case 0xAC: Y = memory.read(addrABS()); setNZ(Y); cycles += 4
        // LDA abs
        case 0xAD: A = memory.read(addrABS()); setNZ(A); cycles += 4
        // LDX abs
        case 0xAE: X = memory.read(addrABS()); setNZ(X); cycles += 4

        // BCS rel
        case 0xB0: branch(cond: flagC); cycles += 2
        // LDA (zp),Y
        case 0xB1: let addr = addrINDY(penalty: &extra); A = memory.read(addr); setNZ(A); cycles += 5 + extra
        // LDY zp,X
        case 0xB4: Y = memory.read(addrZPX()); setNZ(Y); cycles += 4
        // LDA zp,X
        case 0xB5: A = memory.read(addrZPX()); setNZ(A); cycles += 4
        // LDX zp,Y
        case 0xB6: X = memory.read(addrZPY()); setNZ(X); cycles += 4
        // CLV
        case 0xB8: flagV = false; cycles += 2
        // LDA abs,Y
        case 0xB9: let addr = addrABSY(penalty: &extra); A = memory.read(addr); setNZ(A); cycles += 4 + extra
        // TSX
        case 0xBA: X = SP; setNZ(X); cycles += 2
        // LDY abs,X
        case 0xBC: let addr = addrABSX(penalty: &extra); Y = memory.read(addr); setNZ(Y); cycles += 4 + extra
        // LDA abs,X
        case 0xBD: let addr = addrABSX(penalty: &extra); A = memory.read(addr); setNZ(A); cycles += 4 + extra
        // LDX abs,Y
        case 0xBE: let addr = addrABSY(penalty: &extra); X = memory.read(addr); setNZ(X); cycles += 4 + extra

        // CPY #
        case 0xC0: cmp(Y, fetchByte()); cycles += 2
        // CMP (zp,X)
        case 0xC1: let addr = addrINDX(); cmp(A, memory.read(addr)); cycles += 6
        // CPY zp
        case 0xC4: cmp(Y, memory.read(addrZP())); cycles += 3
        // CMP zp
        case 0xC5: let addr = addrZP(); cmp(A, memory.read(addr)); cycles += 3
        // DEC zp
        case 0xC6:
            let addr = addrZP(); var v = memory.read(addr); v &-= 1; setNZ(v); memory.write(addr, v); cycles += 5
        // INY
        case 0xC8: Y &+= 1; setNZ(Y); cycles += 2
        // CMP #
        case 0xC9: cmp(A, fetchByte()); cycles += 2
        // DEX
        case 0xCA: X &-= 1; setNZ(X); cycles += 2
        // CPY abs
        case 0xCC: cmp(Y, memory.read(addrABS())); cycles += 4
        // CMP abs
        case 0xCD: let addr = addrABS(); cmp(A, memory.read(addr)); cycles += 4
        // DEC abs
        case 0xCE:
            let addr = addrABS(); var v = memory.read(addr); v &-= 1; setNZ(v); memory.write(addr, v); cycles += 6

        // BNE rel
        case 0xD0: branch(cond: !flagZ); cycles += 2
        // CMP (zp),Y
        case 0xD1: let addr = addrINDY(penalty: &extra); cmp(A, memory.read(addr)); cycles += 5 + extra
        // CMP zp,X
        case 0xD5: let addr = addrZPX(); cmp(A, memory.read(addr)); cycles += 4
        // DEC zp,X
        case 0xD6:
            let addr = addrZPX(); var v = memory.read(addr); v &-= 1; setNZ(v); memory.write(addr, v); cycles += 6
        // CLD
        case 0xD8: flagD = false; cycles += 2
        // CMP abs,Y
        case 0xD9: let addr = addrABSY(penalty: &extra); cmp(A, memory.read(addr)); cycles += 4 + extra
        // CMP abs,X
        case 0xDD: let addr = addrABSX(penalty: &extra); cmp(A, memory.read(addr)); cycles += 4 + extra
        // DEC abs,X
        case 0xDE:
            let addr = addrABSX(penalty: &extra); var v = memory.read(addr); v &-= 1; setNZ(v); memory.write(addr, v); cycles += 7

        // CPX #
        case 0xE0: cmp(X, fetchByte()); cycles += 2
        // SBC (zp,X)
        case 0xE1: let addr = addrINDX(); sbc(memory.read(addr)); cycles += 6
        // CPX zp
        case 0xE4: cmp(X, memory.read(addrZP())); cycles += 3
        // SBC zp
        case 0xE5: let addr = addrZP(); sbc(memory.read(addr)); cycles += 3
        // INC zp
        case 0xE6:
            let addr = addrZP(); var v = memory.read(addr); v &+= 1; setNZ(v); memory.write(addr, v); cycles += 5
        // INX
        case 0xE8: X &+= 1; setNZ(X); cycles += 2
        // SBC #
        case 0xE9: sbc(fetchByte()); cycles += 2
        // NOP
        case 0xEA: cycles += 2
        // CPX abs
        case 0xEC: cmp(X, memory.read(addrABS())); cycles += 4
        // SBC abs
        case 0xED: let addr = addrABS(); sbc(memory.read(addr)); cycles += 4
        // INC abs
        case 0xEE:
            let addr = addrABS(); var v = memory.read(addr); v &+= 1; setNZ(v); memory.write(addr, v); cycles += 6

        // BEQ rel
        case 0xF0: branch(cond: flagZ); cycles += 2
        // SBC (zp),Y
        case 0xF1: let addr = addrINDY(penalty: &extra); sbc(memory.read(addr)); cycles += 5 + extra
        // SBC zp,X
        case 0xF5: let addr = addrZPX(); sbc(memory.read(addr)); cycles += 4
        // INC zp,X
        case 0xF6:
            let addr = addrZPX(); var v = memory.read(addr); v &+= 1; setNZ(v); memory.write(addr, v); cycles += 6
        // SED
        case 0xF8: flagD = true; cycles += 2
        // SBC abs,Y
        case 0xF9: let addr = addrABSY(penalty: &extra); sbc(memory.read(addr)); cycles += 4 + extra
        // SBC abs,X
        case 0xFD: let addr = addrABSX(penalty: &extra); sbc(memory.read(addr)); cycles += 4 + extra
        // INC abs,X
        case 0xFE:
            let addr = addrABSX(penalty: &extra); var v = memory.read(addr); v &+= 1; setNZ(v); memory.write(addr, v); cycles += 7

        default:
            cycles += 2
        }
        return Int(cycles)
    }
}
