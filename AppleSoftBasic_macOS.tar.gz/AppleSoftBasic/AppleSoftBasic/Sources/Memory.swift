import Foundation

// MARK: - 64KB Memory with ROM/RAM regions

final class Memory {
    private var ram = [UInt8](repeating: 0, count: 65536)
    var outputCallback: ((UInt8) -> Void)?
    var inputCallback: (() -> UInt8?)?

    // Apple II soft switches / ROM addresses
    static let kbdAddr:  UInt16 = 0xC000  // keyboard data
    static let kbdStrAddr: UInt16 = 0xC010 // keyboard strobe
    static let dspAddr:  UInt16 = 0xD012  // display output (used by Applesoft)
    // Applesoft ROM sits at $D000-$FFFF in Apple II
    // We'll map it starting at 0xD000 (48K) via the ROM overlay

    // MARK: Applesoft BASIC ROM image (Integer BASIC replaced by Applesoft)
    // Loaded at init from embedded resource
    private var romStart: UInt16 = 0xD000
    private var romData: [UInt8] = []

    // Pending keyboard input byte
    var pendingKeyboard: UInt8 = 0x00
    var keyboardReady: Bool = false

    func loadROM(_ data: [UInt8], at address: UInt16) {
        romStart = address
        romData = data
        for (i, byte) in data.enumerated() {
            let addr = Int(address) + i
            if addr < 65536 {
                ram[addr] = byte
            }
        }
    }

    func read(_ addr: UInt16) -> UInt8 {
        let a = Int(addr)
        switch addr {
        case Memory.kbdAddr:
            // Keyboard data – bit 7 set when key ready
            if keyboardReady {
                return pendingKeyboard | 0x80
            }
            return 0x00
        case Memory.kbdStrAddr:
            // Clear strobe on read
            keyboardReady = false
            return 0x00
        case 0xC020...0xC05F:
            return 0x00
        default:
            return ram[a]
        }
    }

    func write(_ addr: UInt16, _ value: UInt8) {
        let a = Int(addr)
        // ROM region is read-only
        if addr >= romStart && !romData.isEmpty {
            return
        }
        ram[a] = value
        // Monitor display output port used by Applesoft
        if addr == Memory.dspAddr || addr == 0xFDED || addr == 0xFDEE {
            let ch = value & 0x7F
            if ch >= 0x20 || ch == 0x0D || ch == 0x0A {
                outputCallback?(ch)
            }
        }
    }

    // Direct RAM access for setup
    func rawWrite(_ addr: UInt16, _ value: UInt8) {
        ram[Int(addr)] = value
    }

    func rawRead(_ addr: UInt16) -> UInt8 {
        return ram[Int(addr)]
    }
}
