import Foundation

// MARK: - Apple II Machine
// Emulates the Apple II hardware environment needed to run Applesoft BASIC.
// Maps the Applesoft ROM, sets up zero-page variables, and hooks I/O.

final class AppleIIMachine {

    let memory: Memory
    let cpu: CPU6502

    // Output ring buffer (thread-safe via lock)
    private let lock = NSLock()
    private var outputBuffer: [Character] = []
    var onOutput: ((String) -> Void)?
    var onInputNeeded: (() -> Void)?

    // Machine state
    private(set) var isRunning = false
    private var thread: Thread?
    private var inputQueue: [UInt8] = []
    private let inputLock = NSLock()

    // Screen content (for re-drawing)
    var screenLines: [String] = []

    init() {
        memory = Memory()
        cpu = CPU6502(memory: memory)
        setupMemory()
        setupIOCallbacks()
    }

    // MARK: - Memory Setup
    private func setupMemory() {
        // Load Applesoft BASIC ROM at $D000
        let romData = AppleSoftROM.data
        memory.loadROM(romData, at: AppleSoftROM.startAddress)

        // Apple II page-zero setup for Applesoft
        // $36-37: TXTPTR  (text pointer)
        // $28-29: TXTTAB  (start of BASIC program)
        // $2A-2B: VARTAB
        // $2C-2D: ARYTAB
        // $2E-2F: STREND
        // $30-31: FRETOP  (top of string space)
        // $32-33: FRESPC
        // $34-35: MEMSIZ  (top of memory)

        // Program starts at $0801 (2049), Apple II convention
        memory.rawWrite(0x67, 0x01)   // TXTTAB lo
        memory.rawWrite(0x68, 0x08)   // TXTTAB hi
        memory.rawWrite(0x69, 0x00)   // VARTAB lo
        memory.rawWrite(0x6A, 0x08)   // VARTAB hi = TXTTAB+1 initially
        memory.rawWrite(0x6B, 0x00)
        memory.rawWrite(0x6C, 0x08)
        memory.rawWrite(0x6D, 0x00)
        memory.rawWrite(0x6E, 0x08)
        memory.rawWrite(0x6F, 0x00)
        memory.rawWrite(0x70, 0xD0)   // FRETOP hi = $D000 (below ROM)
        memory.rawWrite(0x73, 0x00)
        memory.rawWrite(0x74, 0xD0)   // MEMSIZ = $D000

        // Empty program: just $00 $00 at TXTTAB
        memory.rawWrite(0x0801, 0x00)
        memory.rawWrite(0x0802, 0x00)

        // HIMEM/LOMEM pointer
        memory.rawWrite(0x4C, 0x00)
        memory.rawWrite(0x4D, 0xD0)

        // CHRGET zero-page routine at $B1 (standard Apple II location)
        // This routine advances the text pointer and gets next character
        // LDA $0000,X (patched) then falls through
        setupChrget()

        // Set reset vector to Applesoft BASIC cold start ($D000)
        memory.rawWrite(0xFFFC, 0x00)
        memory.rawWrite(0xFFFC + 1, 0xD0)

        // Set up COUT hook ($FDED) – output character in A
        // We intercept via memory write callback
        setupMonitorStubs()
    }

    // MARK: - CHRGET at $B1
    private func setupChrget() {
        // Standard Apple II CHRGET at $B1
        // Increments TXTPTR and loads the char
        var p: UInt16 = 0x00B1
        func wb(_ b: UInt8) { memory.rawWrite(p, b); p += 1 }
        // INC $E6  (low byte of TXTPTR)
        wb(0xE6); wb(0xE6)   // actually at zero page address $E6
        // BNE +2
        wb(0xD0); wb(0x02)
        // INC $E7
        wb(0xE6); wb(0xE7)
        // LDA $0000   ; will be patched to actual ptr
        wb(0xAD); wb(0x00); wb(0x00)
        // CMP #$3A  ':'
        wb(0xC9); wb(0x3A)
        // BCS +2
        wb(0xB0); wb(0x01)
        // SEC
        wb(0x38)
        // SBC #$20
        wb(0xE9); wb(0x20)
        // RTS
        wb(0x60)
    }

    // MARK: - Apple II Monitor ROM stubs
    private func setupMonitorStubs() {
        // COUT ($FDED) — output char in A (strip high bit, output to screen)
        // We intercept writes to $D012 in memory
        // Stub: STA $D012 ; RTS
        var p: UInt16 = 0xFDED
        func wb(_ b: UInt8) { memory.rawWrite(p, b); p += 1 }
        wb(0x8D); wb(0x12); wb(0xD0)   // STA $D012
        wb(0x60)                         // RTS

        // RDKEY ($FD0C) — read keyboard
        // Stub: LDA $C000 ; BPL *-3 ; BIT $C010 ; RTS
        p = 0xFD0C
        wb(0xAD); wb(0x00); wb(0xC0)   // LDA $C000
        wb(0x10); wb(0xFB)              // BPL *-3 (spin waiting)
        wb(0x2C); wb(0x10); wb(0xC0)   // BIT $C010 (clear strobe)
        wb(0x60)                         // RTS

        // HOME ($FC58) — clear screen
        p = 0xFC58
        wb(0x8D); wb(0x13); wb(0xD0)   // STA $D013 (our "clear screen" signal)
        wb(0x60)

        // PRBYTE ($FDDA) — print hex byte in A
        p = 0xFDDA
        wb(0x48)                         // PHA
        wb(0x4A); wb(0x4A); wb(0x4A); wb(0x4A)  // LSR x4
        wb(0x20); wb(0xE5); wb(0xFD)   // JSR PRHEX
        wb(0x68)                         // PLA
        // fall through to PRHEX
        p = 0xFDE5
        wb(0x29); wb(0x0F)              // AND #$0F
        wb(0xC9); wb(0x0A)              // CMP #$0A
        wb(0x90); wb(0x02)              // BCC +2
        wb(0x69); wb(0x06)              // ADC #$06
        wb(0x69); wb(0x30)              // ADC #$30
        // fall through COUT
        wb(0x4C); wb(0xED); wb(0xFD)   // JMP COUT

        // PRNTAX ($F941) stub
        p = 0xF941
        wb(0x20); wb(0xDA); wb(0xFD)   // JSR PRBYTE (A)
        wb(0x8A)                         // TXA
        wb(0x4C); wb(0xDA); wb(0xFD)   // JMP PRBYTE

        // BELL ($FF3A)
        p = 0xFF3A
        wb(0x60)                         // RTS (no bell in emulator)

        // WAIT ($FCA8)
        p = 0xFCA8
        wb(0x60)                         // RTS (no wait)

        // CLREOP ($FC42)
        p = 0xFC42
        wb(0x60)                         // RTS

        // SETINV / SETNRM ($FE80, $FE84)
        p = 0xFE80; wb(0x60)
        p = 0xFE84; wb(0x60)

        // MOVE ($FE2C)
        p = 0xFE2C; wb(0x60)

        // PRERR ($FF2D) - print error
        p = 0xFF2D; wb(0x60)

        // IOSAVE / IOREST ($FF4A, $FF3F)
        p = 0xFF3F; wb(0x60)
        p = 0xFF4A; wb(0x60)

        // NXTA1 ($FCBA)
        p = 0xFCBA
        wb(0xE6); wb(0x32)              // INC $32
        wb(0xD0); wb(0x02)              // BNE +2
        wb(0xE6); wb(0x33)              // INC $33
        // NXTA4 ($FCBC)
        p = 0xFCBC
        wb(0xE6); wb(0x3C)              // INC $3C
        wb(0xD0); wb(0x02)              // BNE +2
        wb(0xE6); wb(0x3D)              // INC $3D
        wb(0x60)                         // RTS

        // GETLN ($FD6F) — input a line (Applesoft calls this for INPUT stmt)
        p = 0xFD6F
        // Store LF char as prompt, then loop reading keyboard
        // We'll route to our custom input handler at $D013 region
        wb(0xA9); wb(0x8D)              // LDA #$8D (CR with high bit)
        wb(0x20); wb(0xED); wb(0xFD)   // JSR COUT
        // Input loop: read chars into $200 (input buffer)
        wb(0xA0); wb(0x00)              // LDY #0
        // inner loop at $FD79
        let innerLoopAddr: UInt16 = p + 4
        wb(0x20); wb(0x0C); wb(0xFD)   // JSR RDKEY
        wb(0xC9); wb(0x8D)              // CMP #$8D (CR)
        wb(0xF0); wb(0x08)              // BEQ done
        wb(0x99); wb(0x00); wb(0x02)   // STA $200,Y
        wb(0x20); wb(0xED); wb(0xFD)   // JSR COUT
        wb(0xC8)                         // INY
        wb(0x4C)                         // JMP inner loop
        let lo = UInt8(innerLoopAddr & 0xFF)
        let hi = UInt8(innerLoopAddr >> 8)
        wb(lo); wb(hi)
        // done: store null terminator
        wb(0x99); wb(0x00); wb(0x02)   // STA $200,Y  (stores CR)
        wb(0xA9); wb(0x8D)              // LDA #$8D
        wb(0x20); wb(0xED); wb(0xFD)   // JSR COUT (echo CR)
        // Set CHRGET to point at $0200
        wb(0xA9); wb(0xFF)              // LDA #$FF  (CHRGET ptr - 1)
        wb(0x85); wb(0xE6)              // STA $E6
        wb(0xA9); wb(0x01)              // LDA #$01
        wb(0x85); wb(0xE7)              // STA $E7
        wb(0x60)                         // RTS
    }

    // MARK: - I/O Callbacks
    private func setupIOCallbacks() {
        memory.outputCallback = { [weak self] byte in
            guard let self = self else { return }
            let ch = Character(UnicodeScalar(byte & 0x7F))
            self.lock.lock()
            self.outputBuffer.append(ch)
            self.lock.unlock()
            // Notify on main thread
            DispatchQueue.main.async {
                self.flushOutput()
            }
        }
    }

    private func flushOutput() {
        lock.lock()
        let chars = outputBuffer
        outputBuffer.removeAll()
        lock.unlock()
        if !chars.isEmpty {
            let s = String(chars)
            onOutput?(s)
        }
    }

    // MARK: - Keyboard Input
    func sendInput(_ text: String) {
        inputLock.lock()
        defer { inputLock.unlock() }
        for ch in text {
            if let scalar = ch.unicodeScalars.first {
                var byte = UInt8(scalar.value & 0x7F)
                if ch == "\n" { byte = 0x0D }
                inputQueue.append(byte | 0x80)  // Apple II sets high bit for valid key
            }
        }
        inputQueue.append(0x8D)  // CR to terminate
    }

    func sendCharacter(_ ascii: UInt8) {
        inputLock.lock()
        memory.pendingKeyboard = ascii | 0x80
        memory.keyboardReady = true
        inputLock.unlock()
    }

    // MARK: - Machine Run/Stop
    func start() {
        guard !isRunning else { return }
        isRunning = true
        cpu.reset()

        thread = Thread {
            self.runLoop()
        }
        thread?.name = "Apple II CPU"
        thread?.qualityOfService = .userInteractive
        thread?.start()
    }

    func stop() {
        isRunning = false
    }

    private func runLoop() {
        // Run at ~1MHz (Apple II clock)
        // Batch execute and throttle
        let cyclesPerBatch = 1000
        let batchDelay = 1_000_000 / 1_000_000  // 1µs per cycle → 1ms per 1000 cycles

        while isRunning && !cpu.halted {
            var batchCycles = 0
            while batchCycles < cyclesPerBatch && isRunning {
                // Feed pending keyboard input to memory
                inputLock.lock()
                if !inputQueue.isEmpty && !memory.keyboardReady {
                    memory.pendingKeyboard = inputQueue.removeFirst()
                    memory.keyboardReady = true
                }
                inputLock.unlock()

                cpu.step()
                batchCycles += 1
            }
            // Small sleep to prevent 100% CPU
            usleep(useconds_t(batchDelay))
        }
        isRunning = false
    }

    func restart() {
        stop()
        Thread.sleep(forTimeInterval: 0.05)
        start()
    }
}
