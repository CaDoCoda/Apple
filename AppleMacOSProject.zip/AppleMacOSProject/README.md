# AppleMacOS Project

This project provides the necessary Swift source files and a CoreML model (`CoreAI.mlpackage`) to create a macOS application.

## Setup Instructions

To set up and run this project in Xcode, follow these steps:

1.  **Create a New Xcode Project**:
    *   Open Xcode.
    *   Go to `File` > `New` > `Project...`.
    *   Select `macOS` > `App` and click `Next`.
    *   For `Product Name`, you can use `AppleMacOS` (or your preferred name).
    *   Ensure `Interface` is set to `SwiftUI` and `Language` is `Swift`.
    *   Click `Next` and choose a location to save your project.

2.  **Add Source Files**:
    *   Navigate to the `Sources` directory within the downloaded project folder.
    *   Drag and drop `AppleMacOSApp.swift`, `ContentView.swift`, and `CoreAIModel.swift` into your Xcode project's `AppleMacOS` group (or your chosen product name group) in the Project Navigator.
    *   When prompted, ensure `Copy items if needed` is checked and `Add to targets` is selected for your main application target.

3.  **Add CoreML Model**:
    *   Navigate to the `Resources` directory within the downloaded project folder.
    *   Drag and drop `CoreAI.mlpackage` into your Xcode project's `Resources` group (or any group you prefer) in the Project Navigator.
    *   When prompted, ensure `Copy items if needed` is checked and `Add to targets` is selected for your main application target.

4.  **Build and Run**:
    *   Select your macOS target and a simulator or your Mac as the run destination.
    *   Click the `Run` button (▶) in Xcode to build and run the application.

## Project Structure

*   `Sources/`:
    *   `AppleMacOSApp.swift`: The main entry point for the SwiftUI application.
    *   `ContentView.swift`: Defines the main user interface, including image selection and prediction display.
    *   `CoreAIModel.swift`: Handles the loading and prediction using the `CoreAI.mlpackage` CoreML model.
*   `Resources/`:
    *   `CoreAI.mlpackage`: The pre-trained CoreML model for image analysis.

## Model Details

The `CoreAI.mlpackage` model expects an image input of `224x224` pixels with `RGB` color space and outputs a `1x2` `FLOAT32` multi-array.

Enjoy building with Core AI on macOS!
