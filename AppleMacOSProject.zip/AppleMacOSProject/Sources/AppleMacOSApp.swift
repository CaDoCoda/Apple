import SwiftUI

@main
struct AppleMacOSApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
