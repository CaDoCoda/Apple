import SwiftUI
import AppKit

struct ContentView: View {
    @State private var selectedImage: NSImage? = nil
    @State private var predictionResult: String = ""
    private let coreAIModel = CoreAIModel()

    var body: some View {
        VStack {
            if let image = selectedImage {
                Image(nsImage: image)
                    .resizable()
                    .scaledToFit()
                    .frame(maxHeight: 300)
            } else {
                Text("Select an image to analyze")
                    .frame(maxWidth: .infinity, maxHeight: 300)
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(10)
            }

            HStack {
                Button("Select Image") {
                    selectImage()
                }
                Button("Analyze Image") {
                    analyzeImage()
                }
                .disabled(selectedImage == nil)
            }
            .padding()

            Text("Prediction: \(predictionResult)")
                .font(.headline)
                .padding()
        }
        .padding()
    }

    private func selectImage() {
        let openPanel = NSOpenPanel()
        openPanel.allowedFileTypes = ["png", "jpg", "jpeg"]
        openPanel.allowsMultipleSelection = false
        openPanel.canChooseDirectories = false

        if openPanel.runModal() == .OK {
            if let url = openPanel.url, let image = NSImage(contentsOf: url) {
                self.selectedImage = image
                self.predictionResult = ""
            }
        }
    }

    private func analyzeImage() {
        guard let image = selectedImage else {
            predictionResult = "No image selected."
            return
        }

        guard let model = coreAIModel else {
            predictionResult = "Model failed to load."
            return
        }

        model.predict(image: image) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let output):
                    self.predictionResult = "\(output)"
                case .failure(let error):
                    self.predictionResult = "Error: \(error.localizedDescription)"
                }
            }
        }
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
