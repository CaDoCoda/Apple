import CoreML
import Vision
import AppKit

@available(macOS 10.15, *) // Adjust minimum macOS version as needed
class CoreAIModel {

    private let model: VNCoreMLModel

    init?() {
        guard let url = Bundle.main.url(forResource: "CoreAI", withExtension: "mlmodelc"),
              let coreMLModel = try? MLModel(contentsOf: url) else {
            print("Error: Could not load CoreAI.mlmodelc")
            return nil
        }
        guard let visionModel = try? VNCoreMLModel(for: coreMLModel) else {
            print("Error: Could not create VNCoreMLModel")
            return nil
        }
        self.model = visionModel
    }

    func predict(image: NSImage, completion: @escaping (Result<[Float], Error>) -> Void) {
        guard let cgImage = image.cgImage(forProposedRect: nil, context: nil, hints: nil) else {
            completion(.failure(CoreAIModelError.imageConversionFailed))
            return
        }

        let request = VNCoreMLRequest(model: model) { [weak self] request, error in
            if let error = error {
                completion(.failure(error))
                return
            }

            guard let observations = request.results as? [VNCoreMLFeatureValueObservation],
                  let multiArray = observations.first?.featureValue.multiArrayValue else {
                completion(.failure(CoreAIModelError.predictionFailed))
                return
            }

            // Assuming the output is a 1x2 Float32 MultiArray
            let output = (0..<multiArray.count).map { multiArray[($0) as NSNumber].floatValue }
            completion(.success(output))
        }

        // Resize image to 224x224 as required by the model
        request.imageCropAndScaleOption = .scaleFill

        let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
        DispatchQueue.global(qos: .userInitiated).async {
            do {
                try handler.perform([request])
            } catch {
                completion(.failure(error))
            }
        }
    }

    enum CoreAIModelError: Error {
        case imageConversionFailed
        case predictionFailed
        case modelLoadingFailed
    }
}
