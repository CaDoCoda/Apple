import Foundation

/// A simple tensor-like structure for handling multidimensional data
public struct Tensor {
    public var data: [Float]
    public var shape: [Int]
    
    public init(shape: [Int], repeating value: Float = 0.0) {
        self.shape = shape
        let count = shape.reduce(1, *)
        self.data = Array(repeating: value, count: count)
    }
    
    public init(data: [Float], shape: [Int]) {
        self.data = data
        self.shape = shape
    }
}

/// Base protocol for neural network layers
public protocol Layer {
    mutating func forward(_ input: Tensor) -> Tensor
    mutating func backward(_ gradient: Tensor) -> Tensor
    mutating func update(learningRate: Float)
}

/// Fully connected layer
public struct Dense: Layer {
    public var weights: [Float] // Flattened [inputSize, outputSize]
    public var biases: [Float]  // [outputSize]
    public let inputSize: Int
    public let outputSize: Int
    
    private var lastInput: [Float] = []
    private var weightGradients: [Float]
    private var biasGradients: [Float]
    
    public init(inputSize: Int, outputSize: Int) {
        self.inputSize = inputSize
        self.outputSize = outputSize
        
        // Xavier/Glorot initialization
        let limit = sqrt(6.0 / Float(inputSize + outputSize))
        self.weights = (0..<(inputSize * outputSize)).map { _ in Float.random(in: -limit...limit) }
        self.biases = Array(repeating: 0.0, count: outputSize)
        
        self.weightGradients = Array(repeating: 0.0, count: inputSize * outputSize)
        self.biasGradients = Array(repeating: 0.0, count: outputSize)
    }
    
    public mutating func forward(_ input: Tensor) -> Tensor {
        self.lastInput = input.data
        var output = [Float](repeating: 0.0, count: outputSize)
        
        for j in 0..<outputSize {
            var sum: Float = biases[j]
            for i in 0..<inputSize {
                sum += lastInput[i] * weights[i * outputSize + j]
            }
            output[j] = sum
        }
        
        return Tensor(data: output, shape: [outputSize])
    }
    
    public mutating func backward(_ gradient: Tensor) -> Tensor {
        let gradData = gradient.data
        var inputGradient = [Float](repeating: 0.0, count: inputSize)
        
        // Reset gradients for this pass
        weightGradients = [Float](repeating: 0.0, count: inputSize * outputSize)
        biasGradients = gradData
        
        for i in 0..<inputSize {
            var sum: Float = 0
            for j in 0..<outputSize {
                let g = gradData[j]
                weightGradients[i * outputSize + j] = lastInput[i] * g
                sum += weights[i * outputSize + j] * g
            }
            inputGradient[i] = sum
        }
        
        return Tensor(data: inputGradient, shape: [inputSize])
    }
    
    public mutating func update(learningRate: Float) {
        for i in 0..<weights.count {
            weights[i] -= learningRate * weightGradients[i]
        }
        for i in 0..<biases.count {
            biases[i] -= learningRate * biasGradients[i]
        }
    }
}

/// ReLU activation layer
public struct ReLU: Layer {
    private var lastInput: [Float] = []
    
    public init() {}
    
    public mutating func forward(_ input: Tensor) -> Tensor {
        self.lastInput = input.data
        let output = input.data.map { max(0, $0) }
        return Tensor(data: output, shape: input.shape)
    }
    
    public mutating func backward(_ gradient: Tensor) -> Tensor {
        var gradData = gradient.data
        for i in 0..<gradData.count {
            if lastInput[i] <= 0 {
                gradData[i] = 0
            }
        }
        return Tensor(data: gradData, shape: gradient.shape)
    }
    
    public mutating func update(learningRate: Float) {}
}

/// Simple Sequential Model
public struct Sequential {
    public var layers: [Layer]
    
    public init(layers: [Layer]) {
        self.layers = layers
    }
    
    public mutating func forward(_ input: Tensor) -> Tensor {
        var current = input
        for i in 0..<layers.count {
            current = layers[i].forward(current)
        }
        return current
    }
    
    public mutating func backward(_ gradient: Tensor) {
        var currentGrad = gradient
        for i in (0..<layers.count).reversed() {
            currentGrad = layers[i].backward(currentGrad)
        }
    }
    
    public mutating func update(learningRate: Float) {
        for i in 0..<layers.count {
            layers[i].update(learningRate: learningRate)
        }
    }
}

/// Loss functions
public struct Loss {
    public static func softmax(_ input: [Float]) -> [Float] {
        let maxVal = input.max() ?? 0
        let exps = input.map { exp($0 - maxVal) }
        let sum = exps.reduce(0, +)
        return exps.map { $0 / sum }
    }
    
    public static func crossEntropyGradient(prediction: [Float], targetIndex: Int) -> [Float] {
        var grad = prediction
        grad[targetIndex] -= 1.0
        return grad
    }
}
