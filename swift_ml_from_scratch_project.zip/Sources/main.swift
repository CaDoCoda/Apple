import Foundation

print("--- Swift ML From Scratch ---")

// 1. Setup Model
let inputSize = 64 // 8x8 images
let hiddenSize = 32
let outputSize = 2 // Binary classification (Vertical vs Horizontal)

var model = Sequential(layers: [
    Dense(inputSize: inputSize, outputSize: hiddenSize),
    ReLU(),
    Dense(inputSize: hiddenSize, outputSize: outputSize)
])

// 2. Generate/Load Data
print("Generating synthetic dataset...")
let trainingData = ImageLoader.generateSyntheticData(count: 1000, size: 8)
let testData = ImageLoader.generateSyntheticData(count: 100, size: 8)

// 3. Train
print("Starting training...")
Trainer.train(model: &model, dataset: trainingData, epochs: 10, lr: 0.01)

// 4. Evaluate
print("\nEvaluating...")
var correct = 0
for (input, label) in testData {
    let output = model.forward(input)
    let probs = Loss.softmax(output.data)
    if probs.enumerated().max(by: { $0.element < $1.element })?.offset == label {
        correct += 1
    }
}
print("Test Accuracy: \(Float(correct) / Float(testData.count) * 100)%")

// 5. Save
CoreMLWriter.save(model: model, to: "SimpleModel.mlmodel")

print("Done.")
