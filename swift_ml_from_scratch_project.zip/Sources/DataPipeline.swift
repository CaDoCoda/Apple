import Foundation

/// A simple loader for Netpbm format (P2/P5 for grayscale, P3/P6 for RGB)
/// This is used because it's easy to parse without external libraries.
public struct ImageLoader {
    public static func loadP5(at path: String) -> [Float]? {
        guard let data = try? Data(contentsOf: URL(fileURLWithPath: path)) else { return nil }
        
        // Very basic P5 (binary grayscale) parser
        let content = data.split(separator: 10, maxSplits: 4, omittingEmptySubsequences: true)
        guard content.count >= 4 else { return nil }
        
        // Skip header lines (P5, dimensions, maxval)
        // In a real scenario, we'd parse these to get width/height
        // For simplicity, we assume fixed size or handle it via a more robust parser
        
        // Just extract the pixel data (everything after the 3rd newline)
        // This is a placeholder for a real implementation
        return nil 
    }
    
    /// Create synthetic data for demonstration if images are not provided
    public static func generateSyntheticData(count: Int, size: Int) -> [(Tensor, Int)] {
        var dataset: [(Tensor, Int)] = []
        for _ in 0..<count {
            let label = Int.random(in: 0...1)
            var pixels = [Float](repeating: 0.0, count: size * size)
            
            // Generate a simple pattern based on label
            if label == 0 {
                // Vertical line
                let col = Int.random(in: 0..<size)
                for r in 0..<size { pixels[r * size + col] = 1.0 }
            } else {
                // Horizontal line
                let row = Int.random(in: 0..<size)
                for c in 0..<size { pixels[row * size + c] = 1.0 }
            }
            
            dataset.append((Tensor(data: pixels, shape: [size * size]), label))
        }
        return dataset
    }
}

public struct Trainer {
    public static func train(model: inout Sequential, dataset: [(Tensor, Int)], epochs: Int, lr: Float) {
        for epoch in 1...epochs {
            var totalLoss: Float = 0
            var correct = 0
            
            for (input, label) in dataset {
                // Forward
                let output = model.forward(input)
                let probs = Loss.softmax(output.data)
                
                // Loss & Accuracy
                totalLoss += -log(max(probs[label], 1e-15))
                if probs.enumerated().max(by: { $0.element < $1.element })?.offset == label {
                    correct += 1
                }
                
                // Backward
                let grad = Loss.crossEntropyGradient(prediction: probs, targetIndex: label)
                model.backward(Tensor(data: grad, shape: [probs.count]))
                
                // Update
                model.update(learningRate: lr)
            }
            
            print("Epoch \(epoch)/\(epochs) - Loss: \(totalLoss / Float(dataset.count)) - Acc: \(Float(correct) / Float(dataset.count))")
        }
    }
}
