// swift-tools-version: 6.3
// The swift-tools-version declares the minimum version of Swift required to build this package.

import PackageDescription

let package = Package(
    name: "swift-ml-from-scratch",
    targets: [
        // Targets are the basic building blocks of a package, defining a module or a test suite.
        // Targets can depend on other targets in this package and products from dependencies.
        .executableTarget(
            name: "swift-ml-from-scratch"
        ),
        .testTarget(
            name: "swift-ml-from-scratchTests",
            dependencies: ["swift-ml-from-scratch"]
        ),
    ],
    swiftLanguageModes: [.v6]
)
