import Foundation

print("Starting SourceCodeClassifier Tests...")

func testImageClassifier() {
    print("Testing ImageClassifier...")
    let classifier = ImageClassifier()
    let mockImage = NativeImage()
    classifier.classify(image: mockImage) { label, confidence, error in
        if let error = error {
            print("  ImageClassifier classification failed as expected (no model): \(error.localizedDescription)")
        } else {
            print("  ImageClassifier classification result: \(label ?? "None") with confidence \(confidence ?? 0)")
        }
    }
}

func testModelTrainer() {
    print("Testing ModelTrainer...")
    let trainer = ModelTrainer()
    let url = trainer.getModelURLForUpdate()
    print("  Model URL for update: \(url?.path ?? "None")")
}

func testTrainingDataManager() {
    print("Testing TrainingDataManager...")
    let manager = TrainingDataManager()
    let samples = manager.loadTrainingSamples(from: URL(fileURLWithPath: "/tmp"))
    print("  Loaded \(samples.count) samples from /tmp")
}

testImageClassifier()
testModelTrainer()
testTrainingDataManager()

// Keep alive for async tasks
RunLoop.main.run(until: Date(timeIntervalSinceNow: 2))
print("Tests completed.")
