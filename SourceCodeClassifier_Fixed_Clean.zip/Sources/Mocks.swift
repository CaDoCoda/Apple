import Foundation

// MARK: - CoreML Mocks
public class MLModel: @unchecked Sendable {
    public struct Configuration {}
    public var modelDescription: MLModelDescription = MLModelDescription()
    public init(contentsOf url: URL) throws {}
    public func write(to url: URL) throws {}
}

public class MLModelDescription {
    public var inputDescriptionsByName: [String: MLFeatureDescription] = [:]
}

public class MLFeatureDescription {
    public var imageConstraint: MLImageConstraint? = MLImageConstraint()
}

public class MLImageConstraint {}

public protocol MLFeatureProvider {
    var featureNames: Set<String> { get }
    func featureValue(for featureName: String) -> MLFeatureValue?
}

public class MLFeatureValue {
    public init(string: String) {}
    public init(cgImage: Any, constraint: MLImageConstraint) throws {}
}

public class MLDictionaryFeatureProvider: MLFeatureProvider {
    public var featureNames: Set<String> = []
    public init(dictionary: [String: Any]) throws {}
    public func featureValue(for featureName: String) -> MLFeatureValue? { return nil }
}

public protocol MLBatchProvider {
    var count: Int { get }
    func features(at index: Int) -> MLFeatureProvider
}

public class MLArrayBatchProvider: MLBatchProvider {
    public var count: Int = 0
    public init(array: [MLFeatureProvider]) { self.count = array.count }
    public func features(at index: Int) -> MLFeatureProvider { fatalError() }
}

public class MLUpdateTask {
    public init(forModelAt modelURL: URL, trainingData: MLBatchProvider, configuration: MLModelConfiguration, progressHandlers: MLUpdateProgressHandlers) throws {}
    public func resume() {}
}

public class MLModelConfiguration {}

public struct MLUpdateProgressHandlers {
    public enum Event { case trainingBegin, miniBatchEnd, epochEnd }
    public init(forEvents events: [Event], progressHandler: @escaping (MLUpdateContext) -> Void, completionHandler: @escaping (MLUpdateContext) -> Void) {}
}

public class MLUpdateContext {
    public var metrics: [MLUpdateContext.MetricKey: Any] = [:]
    public var model: MLModel = try! MLModel(contentsOf: URL(fileURLWithPath: ""))
    public enum MetricKey { case loss }
}

// MARK: - Vision Mocks
public class VNCoreMLModel: @unchecked Sendable {
    public init(for model: MLModel) throws {}
}

public class VNRequest: @unchecked Sendable {
    public var results: [Any]?
}

public class VNCoreMLRequest: VNRequest {
    public enum ImageCropAndScaleOption { case centerCrop }
    public var imageCropAndScaleOption: ImageCropAndScaleOption = .centerCrop
    public init(model: VNCoreMLModel, completionHandler: @escaping (VNRequest, Error?) -> Void) {}
}

public class VNClassificationObservation {
    public var identifier: String = "Mock"
    public var confidence: Float = 1.0
}

public class VNImageRequestHandler: @unchecked Sendable {
    public init(cgImage: Any, options: [AnyHashable: Any]) {}
    public func perform(_ requests: [VNRequest]) throws {}
}

// MARK: - Platform Mocks
#if os(Linux)
public class UIImage: @unchecked Sendable {
    public init() {}
    public var cgImage: Any? = "MockCGImage"
    public init?(contentsOfFile path: String) {}
    public init?(data: Data) {}
}

public typealias NativeImage = UIImage

public struct PhotosPickerItem {
    public func loadTransferable<T>(type: T.Type) async throws -> T? { return nil }
}
#endif
