import Foundation

#if !canImport(CoreML)
// Use mocks
#else
import CoreML
#endif

class TrainingDataManager {
    struct TrainingSample {
        let image: NativeImage
        let label: String
    }

    func loadTrainingSamples(from directoryURL: URL) -> [TrainingSample] {
        var samples: [TrainingSample] = []
        let fileManager = FileManager.default

        guard let classDirectories = try? fileManager.contentsOfDirectory(at: directoryURL, includingPropertiesForKeys: [.isDirectoryKey], options: .skipsHiddenFiles) else {
            return []
        }

        for classDir in classDirectories {
            let label = classDir.lastPathComponent
            guard let imageFiles = try? fileManager.contentsOfDirectory(at: classDir, includingPropertiesForKeys: nil, options: .skipsHiddenFiles) else { continue }

            for imageFile in imageFiles {
                if let image = NativeImage(contentsOfFile: imageFile.path) {
                    samples.append(TrainingSample(image: image, label: label))
                }
            }
        }
        return samples
    }

    func createBatchProvider(
        from samples: [TrainingSample],
        imageConstraint: MLImageConstraint,
        inputFeatureName: String,
        outputFeatureName: String
    ) -> MLArrayBatchProvider? {
        var featureProviders: [MLFeatureProvider] = []

        for sample in samples {
            let cgImage: Any?
            #if canImport(UIKit)
            cgImage = sample.image.cgImage
            #elseif canImport(AppKit)
            cgImage = sample.image.cgImage(forProposedRect: nil, context: nil, hints: nil)
            #else
            cgImage = sample.image.cgImage
            #endif

            guard let finalCGImage = cgImage else { continue }

            do {
                let imageFeatureValue = try MLFeatureValue(cgImage: finalCGImage, constraint: imageConstraint)
                let labelFeatureValue = MLFeatureValue(string: sample.label)
                let provider = try MLDictionaryFeatureProvider(dictionary: [
                    inputFeatureName: imageFeatureValue,
                    outputFeatureName: labelFeatureValue
                ])
                featureProviders.append(provider)
            } catch {
                continue
            }
        }

        return featureProviders.isEmpty ? nil : MLArrayBatchProvider(array: featureProviders)
    }
}
