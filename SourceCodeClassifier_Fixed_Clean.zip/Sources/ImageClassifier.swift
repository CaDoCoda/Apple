import Foundation

#if !canImport(CoreML)
// Use mocks defined in Mocks.swift
#else
import CoreML
import Vision
#endif

#if canImport(UIKit)
import UIKit
typealias NativeImage = UIImage
#elseif canImport(AppKit)
import AppKit
typealias NativeImage = NSImage
#endif

class ImageClassifier {
    private var visionModel: VNCoreMLModel?
    private let modelName = "UpdatableSourceCodeClassifier"
    private let modelExtension = "mlmodelc"

    private var persistentModelURL: URL {
        #if os(Linux)
        let directory = FileManager.default.homeDirectoryForCurrentUser
        #else
        let directory = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!
        #endif
        return directory.appendingPathComponent(modelName).appendingPathExtension(modelExtension)
    }

    init() {
        setupApplicationSupportDirectory()
        loadModel()
    }

    private func setupApplicationSupportDirectory() {
        let directory = persistentModelURL.deletingLastPathComponent()
        if !FileManager.default.fileExists(atPath: directory.path) {
            try? FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true, attributes: nil)
        }
    }

    func loadModel() {
        let modelURL: URL
        if FileManager.default.fileExists(atPath: persistentModelURL.path) {
            modelURL = persistentModelURL
        } else {
            // In a real app, this would be in the bundle.
            // For testing/Linux, we'll just check a local path or skip.
            return
        }

        do {
            let mlModel = try MLModel(contentsOf: modelURL)
            visionModel = try VNCoreMLModel(for: mlModel)
        } catch {
            print("Error loading model: \(error)")
            visionModel = nil
        }
    }

    func classify(image: NativeImage, completion: @escaping @Sendable (String?, Double?, Error?) -> Void) {
        guard let model = visionModel else {
            completion(nil, nil, NSError(domain: "ImageClassifier", code: 1, userInfo: [NSLocalizedDescriptionKey: "Model not loaded"]))
            return
        }

        let cgImage: Any?
        #if canImport(UIKit)
        cgImage = image.cgImage
        #elseif canImport(AppKit)
        cgImage = image.cgImage(forProposedRect: nil, context: nil, hints: nil)
        #else
        cgImage = image.cgImage
        #endif

        guard let finalCGImage = cgImage else {
            completion(nil, nil, NSError(domain: "ImageClassifier", code: 2, userInfo: [NSLocalizedDescriptionKey: "Invalid Image"]))
            return
        }

        let request = VNCoreMLRequest(model: model) { request, error in
            if let error = error {
                completion(nil, nil, error)
                return
            }
            guard let results = request.results as? [VNClassificationObservation], let topResult = results.first else {
                completion("Unknown", 0.0, nil)
                return
            }
            completion(topResult.identifier, Double(topResult.confidence), nil)
        }

        request.imageCropAndScaleOption = .centerCrop
        let handler = VNImageRequestHandler(cgImage: finalCGImage, options: [:])
        DispatchQueue.global(qos: .userInitiated).async {
            do {
                try handler.perform([request])
            } catch {
                completion(nil, nil, error)
            }
        }
    }
}
