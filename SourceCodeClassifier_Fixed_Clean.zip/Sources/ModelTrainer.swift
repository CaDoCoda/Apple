import Foundation

#if !canImport(CoreML)
// Use mocks
#else
import CoreML
#endif

class ModelTrainer {
    private let modelName = "UpdatableSourceCodeClassifier"
    private let modelExtension = "mlmodelc"

    private var persistentModelURL: URL {
        #if os(Linux)
        let directory = FileManager.default.homeDirectoryForCurrentUser
        #else
        let directory = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!
        #endif
        return directory.appendingPathComponent(modelName).appendingPathExtension(modelExtension)
    }

    func getModelURLForUpdate() -> URL? {
        if FileManager.default.fileExists(atPath: persistentModelURL.path) {
            return persistentModelURL
        }
        return nil // In a real app, check bundle
    }

    func getImageConstraint(from modelURL: URL, inputName: String) -> MLImageConstraint? {
        do {
            let mlModel = try MLModel(contentsOf: modelURL)
            return mlModel.modelDescription.inputDescriptionsByName[inputName]?.imageConstraint
        } catch {
            return nil
        }
    }

    func startUpdateTask(
        modelURL: URL,
        trainingData: MLBatchProvider,
        progressHandler: @escaping (Double) -> Void,
        completion: @escaping (Result<Void, Error>) -> Void
    ) {
        do {
            let updateTask = try MLUpdateTask(
                forModelAt: modelURL,
                trainingData: trainingData,
                configuration: MLModelConfiguration(),
                progressHandlers: MLUpdateProgressHandlers(
                    forEvents: [.trainingBegin, .miniBatchEnd, .epochEnd],
                    progressHandler: { context in
                        if let loss = context.metrics[.loss] as? Double {
                            progressHandler(loss)
                        }
                    },
                    completionHandler: { [weak self] context in
                        self?.saveUpdatedModel(context.model, completion: completion)
                    }
                )
            )
            updateTask.resume()
        } catch {
            completion(.failure(error))
        }
    }

    private func saveUpdatedModel(_ model: MLModel, completion: @escaping (Result<Void, Error>) -> Void) {
        do {
            let directory = persistentModelURL.deletingLastPathComponent()
            if !FileManager.default.fileExists(atPath: directory.path) {
                try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true, attributes: nil)
            }
            try model.write(to: persistentModelURL)
            completion(.success(()))
        } catch {
            completion(.failure(error))
        }
    }
}
