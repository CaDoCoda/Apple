#!/usr/bin/env python3
"""
Hybrid ARM-x86 Architecture Simulator

This simulator demonstrates the interaction between an ARM Single Core Lane
and X86 Multicore Lanes, including task dispatch, execution, and result retrieval.
Modified to accept commands and output JSON for Swift integration.
"""

import struct
import time
import threading
from dataclasses import dataclass
from enum import IntEnum
from typing import Dict, List, Optional
from queue import Queue
import json
import sys
import argparse


class TaskStatus(IntEnum):
    """Task completion status codes."""
    PENDING = 0
    RUNNING = 1
    COMPLETED = 2
    ERROR = 3


class LaneState(IntEnum):
    """State of an x86 lane."""
    POWERED_OFF = 0
    IDLE = 1
    EXECUTING = 2


@dataclass
class TaskDescriptor:
    """Represents a task to be executed on x86 lanes."""
    task_id: int
    flags: int
    instruction_ptr: int
    data_ptr_in: int
    data_size_in: int
    data_ptr_out: int
    data_size_out: int
    completion_status: int = 0
    result_data: bytes = b''

    def to_bytes(self) -> bytes:
        """Serialize the task descriptor to bytes."""
        return struct.pack(
            '<IIQIQIQI20s',
            self.task_id,
            self.flags,
            self.instruction_ptr,
            self.data_ptr_in,
            self.data_size_in,
            self.data_ptr_out,
            self.data_size_out,
            self.completion_status,
            b'\x00' * 20
        )

    @staticmethod
    def from_bytes(data: bytes) -> 'TaskDescriptor':
        """Deserialize a task descriptor from bytes."""
        values = struct.unpack('<IIQIQIQI20s', data)
        return TaskDescriptor(
            task_id=values[0],
            flags=values[1],
            instruction_ptr=values[2],
            data_ptr_in=values[3],
            data_size_in=values[4],
            data_ptr_out=values[5],
            data_size_out=values[6],
            completion_status=values[7]
        )


class HybridControlUnit:
    """
    Hybrid Control Unit (HCU) - Manages communication between ARM and x86 subsystems.
    """

    def __init__(self, num_x86_lanes: int = 4):
        self.num_x86_lanes = num_x86_lanes
        
        # Register map (simulated as a dictionary)
        self.registers = {
            'HCU_STATUS': 0x00000001,  # X86_SUBSYSTEM_READY
            'HCU_CONTROL': 0x00000001,  # WAKE_ON_TASK enabled
            'LANE_ACTIVE_MASK': (1 << num_x86_lanes) - 1,  # All lanes active
            'LANE_IDLE_MASK': (1 << num_x86_lanes) - 1,  # All lanes idle initially
            'TDQ_HEAD': 0,
            'TDQ_TAIL': 0,
            'INTERRUPT_ENABLE': 0x00000001,  # Interrupts enabled
            'INTERRUPT_STATUS': 0x00000000,
        }
        
        # Shared memory simulation
        self.shared_memory = bytearray(1024 * 1024)  # 1 MB
        self.task_queue: Queue = Queue()
        self.completed_tasks: Dict[int, TaskDescriptor] = {}
        self.lane_states: List[LaneState] = [LaneState.IDLE] * num_x86_lanes
        self.lane_threads: List[Optional[threading.Thread]] = [None] * num_x86_lanes
        self.running = False

    def read_register(self, reg_name: str) -> int:
        """Read from a register."""
        return self.registers.get(reg_name, 0)

    def write_register(self, reg_name: str, value: int) -> None:
        """Write to a register."""
        if reg_name in self.registers:
            self.registers[reg_name] = value

    def write_shared_memory(self, offset: int, data: bytes) -> None:
        """Write data to shared memory."""
        end = offset + len(data)
        if end <= len(self.shared_memory):
            self.shared_memory[offset:end] = data

    def read_shared_memory(self, offset: int, size: int) -> bytes:
        """Read data from shared memory."""
        return bytes(self.shared_memory[offset:offset + size])

    def dispatch_task(self, task: TaskDescriptor) -> None:
        """Dispatch a task to the x86 subsystem."""
        self.task_queue.put(task)
        self.registers['HCU_STATUS'] |= 0x00000002  # Set TDQ_FULL if queue is large

    def get_idle_lane(self) -> Optional[int]:
        """Get the index of an idle x86 lane."""
        for i in range(self.num_x86_lanes):
            if self.lane_states[i] == LaneState.IDLE:
                return i
        return None

    def mark_lane_executing(self, lane_id: int) -> None:
        """Mark a lane as executing."""
        self.lane_states[lane_id] = LaneState.EXECUTING
        self.registers['LANE_IDLE_MASK'] &= ~(1 << lane_id)

    def mark_lane_idle(self, lane_id: int) -> None:
        """Mark a lane as idle."""
        self.lane_states[lane_id] = LaneState.IDLE
        self.registers['LANE_IDLE_MASK'] |= (1 << lane_id)

    def signal_interrupt(self) -> None:
        """Signal an interrupt to the ARM core."""
        self.registers['INTERRUPT_STATUS'] |= 0x00000001

    def clear_interrupt(self) -> None:
        """Clear the interrupt status."""
        self.registers['INTERRUPT_STATUS'] = 0x00000000

    def start_lanes(self) -> None:
        self.running = True
        for i in range(self.num_x86_lanes):
            lane = X86Lane(i, self)
            thread = threading.Thread(target=lane.execute, daemon=True)
            thread.start()
            self.lane_threads.append(thread)

    def stop_lanes(self) -> None:
        self.running = False
        for thread in self.lane_threads:
            thread.join(timeout=0.1) # Give a short timeout for threads to finish
        self.lane_threads = []


class X86Lane:
    """Simulates an x86 processor lane."""

    def __init__(self, lane_id: int, hcu: HybridControlUnit):
        self.lane_id = lane_id
        self.hcu = hcu

    def execute(self) -> None:
        """Main execution loop for the x86 lane."""
        while self.hcu.running:
            try:
                task = self.hcu.task_queue.get(timeout=0.1)
                
                self.hcu.mark_lane_executing(self.lane_id)
                
                # print(f"[X86 Lane {self.lane_id}] Executing Task {task.task_id}")
                
                self._simulate_task_execution(task)
                
                self.hcu.completed_tasks[task.task_id] = task
                
                self.hcu.mark_lane_idle(self.lane_id)
                
                if self.hcu.registers['INTERRUPT_ENABLE'] & 0x00000001:
                    self.hcu.signal_interrupt()
                
                # print(f"[X86 Lane {self.lane_id}] Task {task.task_id} completed with status {task.completion_status}")
                
            except Exception:
                # Queue timeout, continue
                pass

    def _simulate_task_execution(self, task: TaskDescriptor) -> None:
        """Simulate the execution of a task."""
        input_data = self.hcu.read_shared_memory(task.data_ptr_in, task.data_size_in)
        
        try:
            values = struct.unpack(f'<{len(input_data)//4}I', input_data[:len(input_data)//4*4])
            result = sum(values)
            
            time.sleep(0.05)
            
            result_bytes = struct.pack('<I', result)
            self.hcu.write_shared_memory(task.data_ptr_out, result_bytes)
            task.result_data = result_bytes
            task.completion_status = 0  # Success
            
        except Exception as e:
            # print(f"[X86 Lane {self.lane_id}] Error processing task: {e}")
            task.completion_status = 1  # Error


class ARMCore:
    """Simulates the ARM Single Core Lane."""

    def __init__(self, hcu: HybridControlUnit):
        self.hcu = hcu
        self.task_counter = 0

    def dispatch_task(self, input_data: bytes, task_name: str = "Task") -> int:
        """
        Dispatch a task from ARM to x86 lanes.
        
        Args:
            input_data: Input data for the task
            task_name: Name of the task for logging
            
        Returns:
            Task ID
        """
        task_id = self.task_counter
        self.task_counter += 1
        
        input_offset = 0x1000 + (task_id * 0x1000)
        output_offset = input_offset + 0x800
        
        self.hcu.write_shared_memory(input_offset, input_data)
        
        task = TaskDescriptor(
            task_id=task_id,
            flags=0,
            instruction_ptr=0x8010_0000,  # Dummy code pointer
            data_ptr_in=input_offset,
            data_size_in=len(input_data),
            data_ptr_out=output_offset,
            data_size_out=0x800,
            completion_status=0
        )
        
        self.hcu.dispatch_task(task)
        # print(f"[ARM Core] Dispatched {task_name} (Task ID: {task_id})")
        
        return task_id

    def wait_for_task(self, task_id: int, timeout: float = 5.0) -> Optional[TaskDescriptor]:
        """
        Wait for a task to complete.
        
        Args:
            task_id: ID of the task to wait for
            timeout: Maximum time to wait in seconds
            
        Returns:
            Completed task descriptor or None if timeout
        """
        start_time = time.time()
        while time.time() - start_time < timeout:
            if task_id in self.hcu.completed_tasks:
                return self.hcu.completed_tasks[task_id]
            time.sleep(0.01)
        
        # print(f"[ARM Core] Timeout waiting for Task {task_id}")
        return None

    def check_interrupt(self) -> bool:
        """Check if an interrupt has been signaled."""
        return bool(self.hcu.registers['INTERRUPT_STATUS'] & 0x00000001)

    def clear_interrupt(self) -> None:
        """Clear the interrupt status."""
        self.hcu.clear_interrupt()


class HybridSystem:
    """Main system orchestrator."""

    def __init__(self, num_x86_lanes: int = 4):
        self.hcu = HybridControlUnit(num_x86_lanes)
        self.arm_core = ARMCore(self.hcu)
        self.x86_lanes = [X86Lane(i, self.hcu) for i in range(num_x86_lanes)]

    def start(self) -> None:
        """Start the hybrid system."""
        # print("[System] Starting Hybrid ARM-x86 System")
        # print(f"[System] Initializing {len(self.x86_lanes)} x86 lanes")
        self.hcu.start_lanes()
        # print("[System] All lanes started")

    def stop(self) -> None:
        """Stop the hybrid system."""
        # print("[System] Stopping Hybrid ARM-x86 System")
        self.hcu.stop_lanes()
        # print("[System] System stopped")

    def handle_command(self, command: str, args: Dict) -> Dict:
        """Handle commands from external interfaces (e.g., Swift)."""
        if command == "dispatch_task":
            input_data_list = args.get("input_data", [])
            input_data_bytes = struct.pack(f'<{len(input_data_list)}I', *input_data_list)
            task_id = self.arm_core.dispatch_task(input_data_bytes)
            return {"task_id": task_id}
        
        elif command == "get_task_result":
            task_id = args.get("task_id")
            if task_id is None:
                return {"error": "task_id not provided"}
            
            completed_task = self.arm_core.wait_for_task(task_id, timeout=0.5)
            if completed_task:
                result_value = struct.unpack('<I', completed_task.result_data)[0] if completed_task.result_data else None
                return {
                    "task_id": task_id,
                    "status": "Completed",
                    "result": result_value
                }
            else:
                return {"task_id": task_id, "status": "Pending", "result": None}

        elif command == "run_demo":
            self.start()
            tasks = []
            for i in range(6):
                input_data = struct.pack('<IIII', i*10, i*20, i*30, i*40)
                task_id = self.arm_core.dispatch_task(input_data, f"Compute Task {i+1}")
                tasks.append(task_id)
                time.sleep(0.01)
            
            results = []
            for task_id in tasks:
                completed_task = self.arm_core.wait_for_task(task_id, timeout=1.0)
                if completed_task:
                    result_value = struct.unpack('<I', completed_task.result_data)[0] if completed_task.result_data else None
                    results.append({
                        'task_id': task_id,
                        'status': 'Completed',
                        'result': result_value
                    })
                else:
                    results.append({
                        'task_id': task_id,
                        'status': 'Timeout',
                        'result': None
                    })
            self.stop()
            return {"demo_results": results}

        else:
            return {"error": f"Unknown command: {command}"}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Hybrid ARM-x86 Architecture Simulator")
    parser.add_argument("--command", required=True, help="Command to execute (e.g., dispatch_task, get_task_result, run_demo)")
    parser.add_argument("--args", type=json.loads, help="JSON string of arguments for the command")
    
    args = parser.parse_args()

    system = HybridSystem(num_x86_lanes=4)
    
    try:
        # Start lanes if not a single command that starts/stops them (like run_demo)
        if args.command not in ["run_demo"]:
            system.start()

        result = system.handle_command(args.command, args.args if args.args else {})
        print(json.dumps(result))

        if args.command not in ["run_demo"]:
            system.stop()

    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)

    sys.exit(0)
