import Foundation

/// Errors that can occur when interacting with the hybrid simulator.
enum SimulatorError: Error {
    case pythonScriptNotFound
    case executionFailed(String)
    case invalidOutput(String)
    case jsonParsingFailed(Error)
}

/// Represents the result of a task executed on the hybrid architecture.
struct TaskResult: Codable {
    let taskId: Int
    let status: String
    let result: Int?
    
    enum CodingKeys: String, CodingKey {
        case taskId = "task_id"
        case status
        case result
    }
}

/// A client for interacting with the Python-based hybrid ARM-x86 simulator.
class HybridSimulatorClient {
    private let pythonExecutablePath: String
    private let simulatorScriptPath: String

    /// Initializes the simulator client.
    /// - Parameters:
    ///   - pythonExecutablePath: The path to the Python 3 executable (e.g., "/usr/bin/python3").
    ///   - simulatorScriptPath: The path to the `hybrid_simulator.py` script.
    init(pythonExecutablePath: String, simulatorScriptPath: String) {
        self.pythonExecutablePath = pythonExecutablePath
        self.simulatorScriptPath = simulatorScriptPath
    }

    /// Runs a command on the Python simulator.
    /// - Parameters:
    ///   - command: The command to execute (e.g., "dispatch_task").
    ///   - arguments: A dictionary of arguments for the command.
    /// - Returns: The JSON-encoded response data from the simulator.
    private func runPythonCommand(command: String, arguments: [String: Any]? = nil) async throws -> Data {
        let process = Process()
        let pipe = Pipe()
        let errorPipe = Pipe()

        process.executableURL = URL(fileURLWithPath: pythonExecutablePath)
        
        var args = [simulatorScriptPath, "--command", command]
        if let arguments = arguments {
            let jsonData = try JSONSerialization.data(withJSONObject: arguments)
            if let jsonString = String(data: jsonData, encoding: .utf8) {
                args.append("--args")
                args.append(jsonString)
            }
        }
        
        process.arguments = args
        process.standardOutput = pipe
        process.standardError = errorPipe

        do {
            try process.run()
        } catch {
            throw SimulatorError.executionFailed(error.localizedDescription)
        }

        let data = pipe.fileHandleForReading.readDataToEndOfFile()
        let errorData = errorPipe.fileHandleForReading.readDataToEndOfFile()
        
        process.waitUntilExit()

        if process.terminationStatus != 0 {
            let errorMessage = String(data: errorData, encoding: .utf8) ?? "Unknown error"
            throw SimulatorError.executionFailed(errorMessage)
        }

        return data
    }

    /// Dispatches a task to the hybrid simulator.
    /// - Parameter inputData: An array of unsigned 32-bit integers to be processed.
    /// - Returns: The ID of the dispatched task.
    func dispatchTask(inputData: [UInt32]) async throws -> Int {
        let args: [String: Any] = ["input_data": inputData]
        let responseData = try await runPythonCommand(command: "dispatch_task", arguments: args)
        
        guard let json = try? JSONSerialization.jsonObject(with: responseData) as? [String: Any],
              let taskId = json["task_id"] as? Int else {
            let output = String(data: responseData, encoding: .utf8) ?? "No output"
            throw SimulatorError.invalidOutput("Failed to parse task_id from response: \(output)")
        }
        
        return taskId
    }

    /// Retrieves the result of a specific task.
    /// - Parameter taskId: The ID of the task to retrieve.
    /// - Returns: A `TaskResult` object containing the task's status and result.
    func getTaskResult(taskId: Int) async throws -> TaskResult {
        let args: [String: Any] = ["task_id": taskId]
        let responseData = try await runPythonCommand(command: "get_task_result", arguments: args)
        
        let decoder = JSONDecoder()
        do {
            return try decoder.decode(TaskResult.self, from: responseData)
        } catch {
            throw SimulatorError.jsonParsingFailed(error)
        }
    }

    /// Runs the built-in demonstration of the hybrid system.
    /// - Returns: An array of `TaskResult` objects from the demo run.
    func runDemo() async throws -> [TaskResult] {
        let responseData = try await runPythonCommand(command: "run_demo")
        
        guard let json = try? JSONSerialization.jsonObject(with: responseData) as? [String: Any],
              let demoResults = json["demo_results"] as? [[String: Any]] else {
            let output = String(data: responseData, encoding: .utf8) ?? "No output"
            throw SimulatorError.invalidOutput("Failed to parse demo_results from response: \(output)")
        }
        
        let jsonData = try JSONSerialization.data(withJSONObject: demoResults)
        let decoder = JSONDecoder()
        return try decoder.decode([TaskResult].self, from: jsonData)
    }
}
