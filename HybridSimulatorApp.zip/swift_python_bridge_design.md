# Swift-Python Bridge Architecture Design

## 1. Introduction

This document outlines the design for bridging a Swift-based macOS application with the existing Python-based hybrid ARM-x86 simulator. The primary goal is to enable the Swift application to initiate tasks on the simulated hybrid architecture and retrieve results, effectively demonstrating the simulator's functionality through a native macOS interface.

## 2. Bridging Mechanism: Process-Based Communication

Given the sandbox environment and the need for simplicity and robustness, **process-based communication** will be employed. The Swift application will execute the Python simulator script as a separate process. Communication will primarily occur via standard input/output (stdin/stdout) using a structured data format.

### 2.1. Advantages of Process-Based Communication

*   **Isolation:** Python and Swift environments remain separate, reducing dependency conflicts.
*   **Simplicity:** No complex library linking or embedding of interpreters is required.
*   **Robustness:** Errors in one process are less likely to crash the other.
*   **Flexibility:** The Python script can be easily updated or replaced without recompiling the Swift application.

### 2.2. Disadvantages

*   **Overhead:** Process creation and inter-process communication (IPC) can introduce latency compared to in-process solutions.
*   **Data Serialization:** Data must be serialized (e.g., to JSON) for transfer, adding a small computational cost.

## 3. Communication Protocol

### 3.1. Python Side (Server/Worker)

The `hybrid_simulator.py` script will be modified or wrapped to act as a command-line utility that accepts specific commands and parameters, and outputs results in JSON format to `stdout`.

**Input (from Swift via `stdin` or command-line arguments):**

*   **Command:** A string indicating the action to perform (e.g., `dispatch_task`, `get_task_status`, `run_demo`).
*   **Parameters:** JSON-encoded string containing arguments for the command (e.g., `input_data`, `task_id`).

**Output (to Swift via `stdout`):**

*   **Result:** JSON-encoded string containing the command's output (e.g., `task_id`, `completion_status`, `result_data`).
*   **Errors:** Any Python exceptions or error messages will be printed to `stderr`.

### 3.2. Swift Side (Client)

The Swift application will:

1.  Construct a command-line invocation for the Python script.
2.  Pass necessary parameters as command-line arguments or via `stdin`.
3.  Launch the Python script as a `Process`.
4.  Capture `stdout` to read the JSON-encoded results.
5.  Capture `stderr` for error reporting and debugging.
6.  Parse the JSON output into native Swift data structures.

## 4. Swift Interface Design

A Swift class, `HybridSimulatorClient`, will encapsulate the interactions with the Python simulator. This class will provide high-level methods that abstract away the IPC details.

```swift
import Foundation

enum SimulatorError: Error {
    case pythonScriptNotFound
    case executionFailed(String)
    case invalidOutput(String)
    case jsonParsingFailed(Error)
}

struct TaskResult: Decodable {
    let taskId: Int
    let status: String
    let result: Int?
}

class HybridSimulatorClient {
    private let pythonExecutablePath: String
    private let simulatorScriptPath: String

    init(pythonExecutablePath: String, simulatorScriptPath: String) {
        self.pythonExecutablePath = pythonExecutablePath
        self.simulatorScriptPath = simulatorScriptPath
    }

    func runPythonCommand(command: String, arguments: [String: Any]?) async throws -> Data {
        // Implementation to run python script as a subprocess
        // and return stdout data
        fatalError("Not implemented")
    }

    func dispatchTask(inputData: [UInt32]) async throws -> Int {
        let args: [String: Any] = ["command": "dispatch_task", "input_data": inputData]
        let responseData = try await runPythonCommand(command: "dispatchTask", arguments: args)
        guard let json = try? JSONSerialization.jsonObject(with: responseData) as? [String: Any],
              let taskId = json["task_id"] as? Int else {
            throw SimulatorError.invalidOutput("Failed to parse task_id from dispatchTask response")
        }
        return taskId
    }

    func getTaskResult(taskId: Int) async throws -> TaskResult {
        let args: [String: Any] = ["command": "get_task_result", "task_id": taskId]
        let responseData = try await runPythonCommand(command: "getTaskResult", arguments: args)
        let decoder = JSONDecoder()
        return try decoder.decode(TaskResult.self, from: responseData)
    }

    func runDemo() async throws -> [TaskResult] {
        let args: [String: Any] = ["command": "run_demo"]
        let responseData = try await runPythonCommand(command: "runDemo", arguments: args)
        let decoder = JSONDecoder()
        return try decoder.decode([TaskResult].self, from: responseData)
    }
}
```

## 5. Error Handling

*   **Python Errors:** Any output to `stderr` from the Python script will be captured by the Swift application and treated as an error. This allows for detailed debugging information to be passed back.
*   **JSON Parsing Errors:** Swift's `JSONDecoder` and `JSONSerialization` will be used to handle parsing errors, converting them into `SimulatorError.jsonParsingFailed`.
*   **Execution Errors:** Issues like the Python executable not being found or the script failing to launch will be caught as `SimulatorError.executionFailed`.

## 6. Project Structure (Xcode)

The Xcode project will be a standard macOS command-line tool or application. The Python script (`hybrid_simulator.py`) will be included as a resource in the Xcode project bundle, making it accessible at runtime.

```
HybridSimulatorApp/
├── HybridSimulatorApp.xcodeproj/
├── HybridSimulatorApp/
│   ├── AppDelegate.swift
│   ├── ContentView.swift
│   ├── HybridSimulatorClient.swift  // Swift interface to Python
│   ├── main.swift
│   └── Resources/
│       └── hybrid_simulator.py      // Python script
└── Products/
```

## 7. Next Steps

1.  Modify `hybrid_simulator.py` to accept commands and output JSON.
2.  Implement the `runPythonCommand` method in `HybridSimulatorClient.swift`.
3.  Create the Xcode project and integrate `HybridSimulatorClient`.
4.  Develop a simple UI or command-line interface in Swift to interact with the simulator.))
