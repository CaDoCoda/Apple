# Hardware-Software Interface (HSI) and Register Map for Hybrid ARM-x86 Architecture

## 1. Introduction

To transform the conceptual hybrid ARM-x86 architecture into a technical reality, a robust Hardware-Software Interface (HSI) is required. This document defines the low-level mechanisms that enable the "ARM Single Core Lane" to communicate with, dispatch tasks to, and retrieve results from the "X86 Multicore Lanes." The core of this interface is a shared memory region and a set of memory-mapped control registers.

## 2. System Architecture

The system consists of:
*   **Primary Processor (Host):** The ARM Single Core Lane, acting as the system orchestrator, running the primary OS kernel, and handling sequential, low-power tasks.
*   **Secondary Processors (Accelerators):** The X86 Multicore Lanes, acting as high-performance compute nodes for parallelizable or computationally intensive workloads.
*   **Interconnect:** A high-speed, cache-coherent interconnect (e.g., a customized version of PCIe, CXL, or a proprietary on-chip fabric) linking the ARM and x86 domains.
*   **Shared Memory:** A designated region of physical memory accessible by both architectures, used for data transfer and task descriptors.

## 3. Memory Map

The ARM processor communicates with the x86 subsystem via Memory-Mapped I/O (MMIO). A specific physical address range is reserved for the Hybrid Control Unit (HCU).

| Base Address | Region Size | Description |
| :--- | :--- | :--- |
| `0x8000_0000` | 4 KB | Hybrid Control Unit (HCU) Registers |
| `0x8000_1000` | 1 MB | Task Descriptor Queue (TDQ) |
| `0x8010_0000` | Variable | Shared Data Payload Area |

## 4. Hybrid Control Unit (HCU) Register Map

The HCU manages the state of the x86 lanes and facilitates task dispatch. All registers are 32-bit wide.

| Offset | Register Name | Access | Description |
| :--- | :--- | :--- | :--- |
| `0x00` | `HCU_STATUS` | RO | Global status of the x86 subsystem. |
| `0x04` | `HCU_CONTROL` | RW | Global control (reset, power state). |
| `0x08` | `LANE_ACTIVE_MASK` | RW | Bitmask indicating which x86 lanes are powered and active. |
| `0x0C` | `LANE_IDLE_MASK` | RO | Bitmask indicating which active x86 lanes are currently idle. |
| `0x10` | `TDQ_HEAD` | RW | Pointer to the head of the Task Descriptor Queue (written by ARM). |
| `0x14` | `TDQ_TAIL` | RO | Pointer to the tail of the Task Descriptor Queue (updated by x86). |
| `0x18` | `INTERRUPT_ENABLE` | RW | Enable interrupts from x86 to ARM (e.g., task completion). |
| `0x1C` | `INTERRUPT_STATUS` | RW1C | Interrupt status flags (write 1 to clear). |

### 4.1. Register Details

**`HCU_STATUS` (0x00)**
*   Bit 0: `X86_SUBSYSTEM_READY` (1 = Ready, 0 = Initializing/Fault)
*   Bit 1: `TDQ_FULL` (1 = Queue Full, cannot accept new tasks)
*   Bits 31:2: Reserved

**`HCU_CONTROL` (0x04)**
*   Bit 0: `X86_SUBSYSTEM_RESET` (Write 1 to trigger hard reset)
*   Bit 1: `WAKE_ON_TASK` (1 = Automatically wake sleeping lanes when TDQ is not empty)
*   Bits 31:2: Reserved

## 5. Task Descriptor Format

Tasks are dispatched by writing a Task Descriptor to the Task Descriptor Queue (TDQ) in shared memory. The TDQ operates as a ring buffer.

A Task Descriptor is a 64-byte structure:

| Offset | Field Name | Size | Description |
| :--- | :--- | :--- | :--- |
| `0x00` | `TaskID` | 32-bit | Unique identifier for the task. |
| `0x04` | `Flags` | 32-bit | Execution flags (e.g., priority, required lane count). |
| `0x08` | `InstructionPtr` | 64-bit | Physical address of the x86 code entry point. |
| `0x10` | `DataPtr_In` | 64-bit | Physical address of the input data payload. |
| `0x18` | `DataSize_In` | 32-bit | Size of the input data in bytes. |
| `0x1C` | `DataPtr_Out` | 64-bit | Physical address for the output data payload. |
| `0x24` | `DataSize_Out` | 32-bit | Maximum size of the output data buffer. |
| `0x28` | `CompletionStatus`| 32-bit | Written by x86 upon completion (0 = Success, Error Code otherwise). |
| `0x2C` | `Reserved` | 20 bytes | Padding for future expansion. |

## 6. Execution Flow (ARM to x86)

1.  **Preparation:** The ARM core prepares the input data and the x86 executable code in the Shared Data Payload Area.
2.  **Descriptor Creation:** The ARM core constructs a Task Descriptor in the TDQ, pointing to the code and data.
3.  **Dispatch:** The ARM core increments the `TDQ_HEAD` register in the HCU.
4.  **Execution:**
    *   The HCU detects the updated `TDQ_HEAD`.
    *   If an x86 lane is idle (checked via `LANE_IDLE_MASK`), the HCU assigns the task to that lane.
    *   The x86 lane reads the Task Descriptor, fetches the code and data, and executes the workload.
5.  **Completion:**
    *   The x86 lane writes the result to `DataPtr_Out`.
    *   The x86 lane updates the `CompletionStatus` in the Task Descriptor.
    *   The x86 lane increments the `TDQ_TAIL` register.
    *   The HCU triggers an interrupt to the ARM core (if enabled in `INTERRUPT_ENABLE`).
6.  **Retrieval:** The ARM core handles the interrupt, reads the `CompletionStatus`, and processes the output data.

## 7. Conclusion

This Hardware-Software Interface provides a concrete mechanism for realizing the hybrid ARM-x86 architecture. By utilizing memory-mapped registers for control and a shared memory queue for task dispatch, the system can efficiently route workloads between the power-efficient ARM lane and the high-performance x86 multicore lanes.
