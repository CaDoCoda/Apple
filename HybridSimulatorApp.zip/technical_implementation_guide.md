# Technical Implementation Guide for Hybrid ARM-x86 Architecture

## 1. Introduction

This document provides a comprehensive technical implementation guide for a conceptual hybrid computing system that integrates ARM single-core processing with x86 multi-core capabilities. Building upon the initial Instruction Set Architecture (ISA) definition and the Hardware-Software Interface (HSI) specification, this guide details the architectural components, communication mechanisms, and a Python-based simulator to demonstrate its functionality.

The goal of this hybrid architecture is to harness the power efficiency of ARM for sequential tasks and the high-performance, multi-threaded capabilities of x86 for computationally intensive workloads, enabling dynamic task offloading and optimized resource utilization.

## 2. Architectural Overview

The hybrid system is composed of two primary processing domains and a dedicated control unit:

*   **ARM Single Core Lane (Host Processor):** This acts as the system orchestrator, responsible for running the primary operating system, managing system resources, and handling general-purpose, power-efficient tasks. It initiates and monitors tasks dispatched to the x86 lanes.
*   **X86 Multicore Lanes (Accelerator Processors):** These lanes are designed for parallel execution of demanding workloads. They operate as accelerators, receiving tasks from the ARM core, executing them, and returning results.
*   **Hybrid Control Unit (HCU):** A critical component that facilitates communication and control between the ARM and x86 domains. It manages task queues, lane states, and interrupt signaling.

### 2.1. Interconnect and Shared Memory

Communication between the ARM core and the x86 lanes is achieved through a high-speed, cache-coherent interconnect and a designated shared memory region. This shared memory is crucial for:

*   **Task Descriptor Queue (TDQ):** A ring buffer in shared memory where the ARM core places task descriptors for x86 execution.
*   **Shared Data Payload Area:** A region for transferring input data to x86 lanes and receiving output data back to the ARM core.

## 3. Hardware-Software Interface (HSI) Specification

The HSI defines the low-level mechanisms for interaction, primarily through Memory-Mapped I/O (MMIO) registers and a structured Task Descriptor format.

### 3.1. Memory Map

The ARM processor accesses the x86 subsystem via a reserved physical address range for the HCU:

| Base Address | Region Size | Description |
| :--- | :--- | :--- |
| `0x8000_0000` | 4 KB | Hybrid Control Unit (HCU) Registers |
| `0x8000_1000` | 1 MB | Task Descriptor Queue (TDQ) |
| `0x8010_0000` | Variable | Shared Data Payload Area |

### 3.2. Hybrid Control Unit (HCU) Register Map

All HCU registers are 32-bit wide and provide control and status information for the x86 subsystem:

| Offset | Register Name | Access | Description |
| :--- | :--- | :--- | :--- |
| `0x00` | `HCU_STATUS` | RO | Global status of the x86 subsystem. |
| `0x04` | `HCU_CONTROL` | RW | Global control (reset, power state). |
| `0x08` | `LANE_ACTIVE_MASK` | RW | Bitmask indicating which x86 lanes are powered and active. |
| `0x0C` | `LANE_IDLE_MASK` | RO | Bitmask indicating which active x86 lanes are currently idle. |
| `0x10` | `TDQ_HEAD` | RW | Pointer to the head of the Task Descriptor Queue (written by ARM). |
| `0x14` | `TDQ_TAIL` | RO | Pointer to the tail of the Task Descriptor Queue (updated by x86). |
| `0x18` | `INTERRUPT_ENABLE` | RW | Enable interrupts from x86 to ARM (e.g., task completion). |
| `0x1C` | `INTERRUPT_STATUS` | RW1C | Interrupt status flags (write 1 to clear). |

### 3.3. Task Descriptor Format

Tasks are defined by a 64-byte Task Descriptor placed in the TDQ:

| Offset | Field Name | Size | Description |
| :--- | :--- | :--- | :--- |
| `0x00` | `TaskID` | 32-bit | Unique identifier for the task. |
| `0x04` | `Flags` | 32-bit | Execution flags (e.g., priority, required lane count). |
| `0x08` | `InstructionPtr` | 64-bit | Physical address of the x86 code entry point. |
| `0x10` | `DataPtr_In` | 64-bit | Physical address of the input data payload. |
| `0x18` | `DataSize_In` | 32-bit | Size of the input data in bytes. |
| `0x1C` | `DataPtr_Out` | 64-bit | Physical address for the output data payload. |
| `0x24` | `DataSize_Out` | 32-bit | Maximum size of the output data buffer. |
| `0x28` | `CompletionStatus`| 32-bit | Written by x86 upon completion (0 = Success, Error Code otherwise). |
| `0x2C` | `Reserved` | 20 bytes | Padding for future expansion. |

## 4. Execution Flow: ARM to x86 Task Offloading

The process of offloading a task from the ARM core to an x86 lane involves several steps:

1.  **Task Preparation (ARM):** The ARM core prepares the necessary input data and the x86 executable code. This code and data are placed in the Shared Data Payload Area.
2.  **Task Descriptor Creation (ARM):** An ARM-side driver constructs a `TaskDescriptor` structure, populating fields such as `TaskID`, `InstructionPtr` (pointing to the x86 code), `DataPtr_In`, `DataSize_In`, `DataPtr_Out`, and `DataSize_Out`. This descriptor is then written to the next available slot in the TDQ.
3.  **Task Dispatch (ARM):** The ARM core updates the `TDQ_HEAD` register in the HCU, signaling that a new task is available.
4.  **Task Detection and Assignment (HCU/x86):** The HCU continuously monitors the `TDQ_HEAD` and `TDQ_TAIL` registers. When a new task is detected (`TDQ_HEAD` > `TDQ_TAIL`), the HCU checks the `LANE_IDLE_MASK` to find an available x86 lane. Once an idle lane is identified, the HCU assigns the task to it and updates the `LANE_IDLE_MASK` accordingly.
5.  **Task Execution (x86):** The assigned x86 lane reads the `TaskDescriptor` from the TDQ, fetches the x86 code and input data from the Shared Data Payload Area, and begins execution. During execution, the `CompletionStatus` in the descriptor might be updated to `RUNNING`.
6.  **Task Completion (x86):** Upon completion, the x86 lane writes any output data to `DataPtr_Out` in the Shared Data Payload Area. It then updates the `CompletionStatus` field in the `TaskDescriptor` (e.g., to `COMPLETED` or `ERROR`) and increments the `TDQ_TAIL` register in the HCU.
7.  **Interrupt Signaling (HCU):** If enabled via `INTERRUPT_ENABLE`, the HCU generates an interrupt to the ARM core, notifying it of task completion.
8.  **Result Retrieval (ARM):** The ARM core, either by polling `TDQ_TAIL` or in response to an interrupt, reads the `CompletionStatus` and retrieves the output data from the Shared Data Payload Area.

## 5. Python-based Simulator

A Python-based simulator (`hybrid_simulator.py`) has been developed to demonstrate the core principles of this hybrid architecture. The simulator models the ARM core, x86 lanes, and the Hybrid Control Unit (HCU), including the shared memory and register interactions.

### 5.1. Simulator Components

*   **`TaskDescriptor` Class:** Represents the structure of a task, including its ID, pointers to input/output data, and completion status.
*   **`HybridControlUnit` Class:** Simulates the HCU, managing registers, shared memory, task queues, and lane states. It handles task dispatch and interrupt signaling.
*   **`X86Lane` Class:** Simulates an individual x86 processing lane. Each lane runs in a separate thread, continuously checking the HCU for new tasks. It simulates task execution and updates the task descriptor upon completion.
*   **`ARMCore` Class:** Simulates the ARM core, responsible for creating and dispatching tasks to the HCU, and waiting for their completion.
*   **`HybridSystem` Class:** Orchestrates the entire simulation, initializing the HCU, ARM core, and x86 lanes, and managing their lifecycle.

### 5.2. Simulator Functionality

The simulator demonstrates:

*   **Task Dispatch:** The ARM core creates tasks with sample input data and dispatches them to the HCU.
*   **Parallel Execution:** Multiple x86 lanes can pick up and execute tasks concurrently.
*   **Result Retrieval:** The ARM core waits for and retrieves results from completed x86 tasks.
*   **Shared Memory Interaction:** Input and output data are passed via a simulated shared memory region.
*   **Register-based Control:** The HCU registers are used to manage lane states and task queue pointers.

### 5.3. Running the Simulator

To run the simulator, execute the `hybrid_simulator.py` script:

```bash
python3 hybrid_simulator.py
```

The output will show the ARM core dispatching tasks, x86 lanes executing them, and the ARM core receiving results, along with an execution summary.

## 6. Conclusion

This technical implementation guide, coupled with the HSI specification and the Python simulator, provides a foundational understanding of how a hybrid ARM-x86 architecture can be realized. The defined interfaces and simulated interactions lay the groundwork for further development, including detailed microarchitectural design, operating system integration, and software development toolchains for such a heterogeneous computing platform. This approach promises to deliver systems that can dynamically adapt to diverse workloads, optimizing for both power efficiency and raw performance.
