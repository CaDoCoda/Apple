# Guide for Setting Up and Running the Hybrid Simulator Xcode Project on macOS

This guide provides step-by-step instructions to set up and run the Swift-based client for the Hybrid ARM-x86 Simulator within an Xcode project on macOS.

## 1. Prerequisites

Before you begin, ensure you have the following installed:

*   **Xcode:** Download and install Xcode from the Mac App Store. This includes the Swift compiler and necessary development tools.
*   **Python 3:** macOS typically comes with Python 3 pre-installed. You can verify by running `python3 --version` in your Terminal. If not installed, download it from [python.org](https://www.python.org/downloads/).
*   **Project Files:** Ensure you have the following files:
    *   `hybrid_simulator.py` (the Python simulator script)
    *   `HybridSimulatorClient.swift` (the Swift client for the simulator)
    *   `main.swift` (the main Swift application file)

## 2. Create a New Xcode Project

1.  **Open Xcode:** Launch Xcode from your Applications folder.
2.  **Create a new project:** From the Xcode welcome screen, select 
`Create a new Xcode project` or go to `File > New > Project...`.
3.  **Choose a template:** Select `macOS` tab, then `Command Line Tool`, and click `Next`.
4.  **Configure your project:**
    *   **Product Name:** `HybridSimulatorApp` (or your preferred name)
    *   **Team:** Your Apple Developer Team (if you have one, otherwise select `None`)
    *   **Organization Identifier:** A reverse domain name identifier (e.g., `com.example`)
    *   **Interface:** `Storyboard` (this option might not appear for Command Line Tool, which is fine)
    *   **Language:** `Swift`
    *   Click `Next`.
5.  **Save the project:** Choose a location to save your project and click `Create`.

## 3. Add Project Files

1.  **Drag and Drop:** Drag the `HybridSimulatorClient.swift` and `main.swift` files into your Xcode project navigator (the left sidebar). When prompted, ensure `Copy items if needed` is checked and `Add to targets` is selected for your `HybridSimulatorApp` target.
2.  **Add Python Script as Resource:**
    *   In the Xcode project navigator, select your project target (`HybridSimulatorApp`).
    *   Go to the `Build Phases` tab.
    *   Expand `Copy Bundle Resources`.
    *   Click the `+` button and select `Add Other...`.
    *   Navigate to where you saved `hybrid_simulator.py`, select it, and click `Add`.
    *   Ensure `Create folder references for any added folders` is NOT checked (it should be `Create groups`).

## 4. Configure Python Executable Path in Swift

In `main.swift`, you need to ensure the `pythonPath` and `scriptPath` variables correctly point to your Python 3 executable and the bundled Python script.

```swift
// --- Setup ---
let pythonPath = "/usr/bin/python3" // Verify this path on your system

// This path assumes hybrid_simulator.py is copied into the app's bundle resources
// and is accessible relative to the executable.
let scriptPath = Bundle.main.path(forResource: "hybrid_simulator", ofType: "py") ?? ""

// Ensure the script path is valid
if scriptPath.isEmpty {
    fatalError("Error: hybrid_simulator.py not found in application bundle.")
}

let client = HybridSimulatorClient(pythonExecutablePath: pythonPath, simulatorScriptPath: scriptPath)
```

**Important:** The `pythonPath` might vary depending on your system or Python installation. Common paths include `/usr/bin/python3`, `/usr/local/bin/python3`, or paths within a virtual environment. You can find your Python 3 path by running `which python3` in your Terminal.

## 5. Build and Run the Project

1.  **Select Scheme:** In Xcode, ensure your `HybridSimulatorApp` scheme is selected (usually next to the Play/Stop buttons).
2.  **Build:** Go to `Product > Build` or press `Cmd + B`.
3.  **Run:** Go to `Product > Run` or press `Cmd + R`.

Xcode will compile and run your Swift application. You should see output in Xcode's console demonstrating the Python simulator's task dispatch and result retrieval.

## 6. Troubleshooting

*   **`pythonScriptNotFound` Error:** Double-check that `hybrid_simulator.py` is correctly added to `Copy Bundle Resources` in your target's `Build Phases` and that the `scriptPath` in `main.swift` is correctly resolving.
*   **`executionFailed` Error:**
    *   Verify `pythonPath` in `main.swift` points to a valid Python 3 executable.
    *   Check Xcode's console for any `stderr` output from the Python script, which might indicate Python-specific errors (e.g., syntax errors, missing modules).
*   **`jsonParsingFailed` or `invalidOutput` Error:** Ensure the Python script is outputting valid JSON to `stdout` and that the Swift `TaskResult` struct matches the JSON structure.

This setup allows your Swift application to leverage the Python simulator as a backend process, demonstrating a practical approach to integrating different language environments for complex system simulations.
