// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "Project_Drew",
    targets: [
        .executableTarget(
            name: "Project_Drew"
        ),
    ]
)
