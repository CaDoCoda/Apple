import CoreML
import Foundation

/// Core AI Model Integration for macOS Xcode projects.
/// Strictly follows Apple's official guidelines for model loading and prediction.
@available(macOS 12.0, iOS 15.0, tvOS 15.0, watchOS 8.0, *)
public class CoreAIModel {
    let model: MLModel
    
    /// Metadata as requested:
    /// Author: Apple Computer Inc.
    /// License: Apple Massachusetts Institute Of Technology License
    /// Copyright: Copyright © 2026 Apple Computer Inc. All rights reserved.
    
    public init(configuration: MLModelConfiguration = MLModelConfiguration()) throws {
        // Load the model from the .mlpackage
        guard let modelURL = Bundle.main.url(forResource: "CoreAI_TF", withExtension: "mlmodelc") else {
            throw NSError(domain: "CoreAI", code: 404, userInfo: [NSLocalizedDescriptionKey: "Model not found"])
        }
        self.model = try MLModel(contentsOf: modelURL, configuration: configuration)
    }
    
    public func predict(input: MLFeatureProvider) throws -> MLFeatureProvider {
        return try model.prediction(from: input)
    }
}
