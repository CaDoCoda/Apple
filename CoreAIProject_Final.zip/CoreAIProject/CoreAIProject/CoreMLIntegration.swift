import Foundation
import CoreML

/// A handler for performing predictions using the CoreAI model.
class CoreAIModelHandler {
    private let model: CoreAI
    
    init() throws {
        // Initialize the CoreAI model. 
        // Note: Xcode automatically generates the 'CoreAI' class from CoreAI.mlmodel.
        let config = MLModelConfiguration()
        self.model = try CoreAI(configuration: config)
    }
    
    /**
     Performs a prediction using the CoreAI model.
     
     - Parameter input: The input data for the model (input_1).
     - Returns: The prediction result (var_24).
     - Throws: An error if the prediction fails.
     */
    func predict(input: CoreAIInput) throws -> CoreAIOutput {
        return try model.prediction(input: input)
    }
}
