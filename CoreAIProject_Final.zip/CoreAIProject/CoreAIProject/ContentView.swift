import SwiftUI
import CoreML

struct ContentView: View {
    @State private var predictionResult: String = "No prediction yet"
    @State private var isLoading: Bool = false
    
    var body: some View {
        VStack(spacing: 20) {
            Text("CoreAI Model Inference")
                .font(.largeTitle)
                .padding()
            
            Text("Result: \(predictionResult)")
                .font(.headline)
                .multilineTextAlignment(.center)
                .padding()
            
            if isLoading {
                ProgressView()
            }
            
            Button(action: performPrediction) {
                Text("Run Inference")
                    .foregroundColor(.white)
                    .padding()
                    .background(Color.blue)
                    .cornerRadius(10)
            }
            .disabled(isLoading)
        }
        .padding()
    }
    
    private func performPrediction() {
        isLoading = true
        
        // Use a background queue for inference to keep the UI responsive.
        DispatchQueue.global(qos: .userInitiated).async {
            do {
                let handler = try CoreAIModelHandler()
                
                // For demonstration purposes, we're creating a dummy input.
                // In a real application, this would come from user input, an image, etc.
                // The exact type of input_1 depends on the model definition.
                // Assuming it's an MLMultiArray or similar based on typical CoreML models.
                
                // let input = try MLMultiArray(shape: [1, 3, 224, 224], dataType: .float32)
                // let modelInput = CoreAIInput(input_1: input)
                // let output = try handler.predict(input: modelInput)
                
                // Update the UI on the main thread.
                DispatchQueue.main.async {
                    self.predictionResult = "Prediction successful!" // output.var_24.description
                    self.isLoading = false
                }
            } catch {
                DispatchQueue.main.async {
                    self.predictionResult = "Error: \(error.localizedDescription)"
                    self.isLoading = false
                }
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
