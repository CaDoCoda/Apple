import SwiftUI

@main
struct CoreAIProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
