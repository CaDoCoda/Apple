/*
 * Copyright: (©) 2026 by Apple Computer, Inc., All Rights Reserved.
 *
 * This source code is licensed under the license found in the
 * LICENSE file in the root directory of this source tree.
 */

import Foundation

// Apple BASIC 6502 Source Project
// This project contains the converted assembly source for Apple Integer BASIC.

print("Apple BASIC 6502 Source Project")
print("-------------------------------")
print("This project is configured to include the assembly source files.")
print("The converted source: Apple_converted.S")
