/*
 * Copyright: (©) 2026 by Apple Computer, Inc., All Rights Reserved.
 *
 * This source code is licensed under the license found in the
 * LICENSE file in the root directory of this source tree.
 */

// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "AppleBASICProject",
    products: [
        .executable(name: "AppleBASICProject", targets: ["AppleBASICProject"]),
    ],
    targets: [
        .executableTarget(
            name: "AppleBASICProject",
            dependencies: []
        ),
    ]
)
