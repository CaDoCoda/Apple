import SwiftUI
import CoreML
import Vision

struct ContentView: View {
    @State private var selectedImage: UIImage? = nil
    @State private var showImagePicker: Bool = false
    @State private var classificationResult: String = "Select an image to classify"
    @State private var isProcessing: Bool = false

    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                ZStack {
                    RoundedRectangle(cornerRadius: 12)
                        .fill(Color.secondary.opacity(0.1))
                        .frame(height: 300)
                    
                    if let selectedImage = selectedImage {
                        Image(uiImage: selectedImage)
                            .resizable()
                            .scaledToFit()
                            .cornerRadius(12)
                            .padding()
                    } else {
                        VStack {
                            Image(systemName: "photo.on.rectangle")
                                .font(.system(size: 60))
                                .foregroundColor(.secondary)
                            Text("No Image Selected")
                                .foregroundColor(.secondary)
                        }
                    }
                }
                .padding(.horizontal)

                VStack(alignment: .leading, spacing: 10) {
                    Text("Classification Result:")
                        .font(.headline)
                    
                    Text(classificationResult)
                        .font(.body)
                        .padding()
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(RoundedRectangle(cornerRadius: 8).stroke(Color.blue.opacity(0.5)))
                }
                .padding(.horizontal)

                Spacer()

                HStack(spacing: 20) {
                    Button(action: { showImagePicker = true }) {
                        Label("Select Photo", systemImage: "photo.fill")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                    }

                    Button(action: { classifyImage() }) {
                        if isProcessing {
                            ProgressView()
                                .progressViewStyle(CircularProgressViewStyle(color: .white))
                        } else {
                            Label("Classify", systemImage: "cpu")
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(selectedImage == nil || isProcessing ? Color.gray : Color.green)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                    .disabled(selectedImage == nil || isProcessing)
                }
                .padding()
            }
            .navigationTitle("CoreAI Classifier")
            .sheet(isPresented: $showImagePicker) {
                ImagePicker(selectedImage: $selectedImage)
            }
        }
    }

    private func classifyImage() {
        guard let uiImage = selectedImage, let ciImage = CIImage(image: uiImage) else {
            classificationResult = "Error: Could not process the selected image."
            return
        }

        isProcessing = true
        classificationResult = "Processing..."

        // Load the model using Vision for native performance
        guard let modelURL = Bundle.main.url(forResource: "CoreAI", withExtension: "mlmodelc") ?? 
                Bundle.main.url(forResource: "CoreAI", withExtension: "mlpackage") else {
            classificationResult = "Error: Model file not found in bundle."
            isProcessing = false
            return
        }

        DispatchQueue.global(qos: .userInitiated).async {
            do {
                let visionModel = try VNCoreMLModel(for: MLModel(contentsOf: modelURL))
                
                let request = VNCoreMLRequest(model: visionModel) { request, error in
                    DispatchQueue.main.async {
                        self.isProcessing = false
                        if let error = error {
                            self.classificationResult = "Error: \(error.localizedDescription)"
                            return
                        }
                        
                        guard let results = request.results as? [VNCoreMLFeatureValueObservation],
                              let multiArray = results.first?.featureValue.multiArrayValue else {
                            self.classificationResult = "Error: Unexpected model output."
                            return
                        }
                        
                        // Handle the [1, 2] shape output natively
                        let class1 = multiArray[0].floatValue
                        let class2 = multiArray[1].floatValue
                        
                        self.classificationResult = String(format: "Confidence Scores:\nClass 1: %.2f%%\nClass 2: %.2f%%", class1 * 100, class2 * 100)
                    }
                }
                
                request.imageCropAndScaleOption = .centerCrop
                
                let handler = VNImageRequestHandler(ciImage: ciImage, options: [:])
                try handler.perform([request])
                
            } catch {
                DispatchQueue.main.async {
                    self.isProcessing = false
                    self.classificationResult = "Error: \(error.localizedDescription)"
                }
            }
        }
    }
}

struct ImagePicker: UIViewControllerRepresentable {
    @Binding var selectedImage: UIImage?
    @Environment(\.presentationMode) var presentationMode

    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
        var parent: ImagePicker

        init(_ parent: ImagePicker) {
            self.parent = parent
        }

        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let image = info[.originalImage] as? UIImage {
                parent.selectedImage = image
            }
            parent.presentationMode.wrappedValue.dismiss()
        }

        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            parent.presentationMode.wrappedValue.dismiss()
        }
    }
}
