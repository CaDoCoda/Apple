import SwiftUI

@main
struct CoreAIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
