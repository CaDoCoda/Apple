# CoreAI Native Xcode Project

This project is optimized for running the `CoreAI.mlpackage` model natively on physical iOS devices using Apple's **Vision framework**.

## Production-Ready Implementation

- **Native Vision Framework**: Uses `VNCoreMLRequest` and `VNImageRequestHandler` for the most efficient on-device inference.
- **On-Device Optimization**: Removes all simulated wrapper classes. Xcode will automatically generate the optimized model interface upon building for a physical device.
- **Asynchronous Processing**: Model inference is performed on a background thread to ensure the UI remains responsive.
- **Permissions**: Includes the necessary `NSPhotoLibraryUsageDescription` in `Info.plist` for accessing user photos on-device.

## Project Structure

- `CoreAIApp/`: Contains the Swift source code and the CoreML model.
  - `CoreAIApp.swift`: The main entry point of the application.
  - `ContentView.swift`: The main UI, leveraging Vision for model interaction.
  - `CoreAI.mlpackage`: The native CoreML model package.
- `CoreAIApp.xcodeproj/`: The Xcode project file.

## How to Deploy on Device

1. Open `CoreAIApp.xcodeproj` in Xcode.
2. Select the `CoreAIApp` target.
3. In the **Signing & Capabilities** tab:
   - Select your **Development Team**.
   - Ensure the **Bundle Identifier** is unique.
4. Connect your physical iOS device.
5. Select your device as the run destination and click **Run**.

## Model Interaction

The app uses the Vision framework to handle image scaling and cropping (`.centerCrop`) automatically, ensuring the image fits the model's 224x224 input requirement perfectly without manual pixel buffer manipulation.
