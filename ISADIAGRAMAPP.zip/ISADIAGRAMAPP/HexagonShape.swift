import SwiftUI

struct HexagonShape: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let w = rect.width
        let h = rect.height
        let cx = rect.midX
        let cy = rect.midY

        // Flat-top hexagon points
        let points: [CGPoint] = [
            CGPoint(x: cx - w * 0.25, y: cy - h * 0.5),
            CGPoint(x: cx + w * 0.25, y: cy - h * 0.5),
            CGPoint(x: cx + w * 0.5,  y: cy),
            CGPoint(x: cx + w * 0.25, y: cy + h * 0.5),
            CGPoint(x: cx - w * 0.25, y: cy + h * 0.5),
            CGPoint(x: cx - w * 0.5,  y: cy),
        ]

        path.move(to: points[0])
        for p in points.dropFirst() {
            path.addLine(to: p)
        }
        path.closeSubpath()
        return path
    }
}
