import SwiftUI

struct ARMLaneView: View {
    let instructions: [Instruction]
    @Binding var selected: Instruction?

    private let laneHeight: CGFloat = 34
    private let dotSize: CGFloat = 26

    var body: some View {
        ZStack {
            // Blue ARM lane bar
            RoundedRectangle(cornerRadius: laneHeight / 2)
                .fill(
                    LinearGradient(
                        colors: [
                            Color(red: 0.31, green: 0.27, blue: 0.90),
                            Color(red: 0.49, green: 0.23, blue: 0.86),
                        ],
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                )
                .frame(height: laneHeight)
                .shadow(color: .purple.opacity(0.4), radius: 10, y: 4)

            // Instruction dots evenly spread along the lane
            GeometryReader { geo in
                let count = instructions.count
                let spacing = geo.size.width / CGFloat(count + 1)
                ForEach(Array(instructions.enumerated()), id: \.element.id) { index, ins in
                    let x = spacing * CGFloat(index + 1)
                    let y = geo.size.height / 2
                    let isSelected = selected == ins

                    Button {
                        withAnimation(.spring(response: 0.3)) {
                            selected = (selected == ins) ? nil : ins
                        }
                    } label: {
                        ZStack {
                            Circle()
                                .fill(isSelected ? Color.blue : Color.white)
                                .frame(width: isSelected ? dotSize + 4 : dotSize,
                                       height: isSelected ? dotSize + 4 : dotSize)
                                .shadow(color: .blue.opacity(isSelected ? 0.6 : 0.2),
                                        radius: isSelected ? 8 : 3)
                                .overlay(
                                    Circle()
                                        .strokeBorder(Color.blue.opacity(0.7),
                                                      lineWidth: isSelected ? 2.5 : 1.5)
                                )

                            Text(ins.mnemonic)
                                .font(.system(size: 7.5, weight: .bold, design: .monospaced))
                                .foregroundColor(isSelected ? .white : .blue)
                        }
                    }
                    .buttonStyle(.plain)
                    .position(x: x, y: y)
                }
            }
        }
    }
}
