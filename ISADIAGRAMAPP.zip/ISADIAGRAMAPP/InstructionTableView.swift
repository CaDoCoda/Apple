import SwiftUI

struct InstructionTableView: View {
    let instructions: [Instruction]
    let arch: Architecture
    @Binding var selected: Instruction?

    private var accentColor: Color {
        arch == .arm ? .blue : Color(red: 0.96, green: 0.65, blue: 0.14)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            // Header row
            HStack {
                Circle()
                    .fill(accentColor)
                    .frame(width: 10, height: 10)
                Text(arch.rawValue)
                    .font(.headline.bold())
                    .foregroundColor(accentColor)
                Spacer()
                Text("\(instructions.count) instructions")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            .padding(.bottom, 8)

            // Column headers
            HStack(spacing: 0) {
                Text("Mnemonic")
                    .frame(width: 80, alignment: .leading)
                Text("Operands")
                    .frame(width: 130, alignment: .leading)
                Text("Encoding")
                    .frame(minWidth: 0, maxWidth: .infinity, alignment: .leading)
            }
            .font(.caption.bold())
            .foregroundColor(.secondary)
            .padding(.vertical, 6)
            .padding(.horizontal, 10)
            .background(accentColor.opacity(0.1))
            .clipShape(RoundedRectangle(cornerRadius: 6))

            // Data rows
            ForEach(Array(instructions.enumerated()), id: \.element.id) { index, ins in
                Button {
                    withAnimation(.spring(response: 0.3)) {
                        selected = (selected == ins) ? nil : ins
                    }
                } label: {
                    HStack(spacing: 0) {
                        Text(ins.mnemonic)
                            .font(.system(.callout, design: .monospaced).bold())
                            .foregroundColor(accentColor)
                            .frame(width: 80, alignment: .leading)
                        Text(ins.operands.isEmpty ? "—" : ins.operands)
                            .font(.system(.caption, design: .monospaced))
                            .foregroundColor(.primary)
                            .frame(width: 130, alignment: .leading)
                        Text(ins.encoding)
                            .font(.system(.caption2, design: .monospaced))
                            .foregroundColor(.secondary)
                            .frame(minWidth: 0, maxWidth: .infinity, alignment: .leading)
                    }
                    .padding(.vertical, 7)
                    .padding(.horizontal, 10)
                    .background(
                        selected == ins
                            ? accentColor.opacity(0.12)
                            : (index % 2 == 0 ? Color.clear : Color.primary.opacity(0.03))
                    )
                    .clipShape(RoundedRectangle(cornerRadius: 4))
                }
                .buttonStyle(.plain)
            }
        }
        .padding(12)
        .background(Color(NSColor.controlBackgroundColor))
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .strokeBorder(accentColor.opacity(0.25), lineWidth: 1)
        )
    }
}
