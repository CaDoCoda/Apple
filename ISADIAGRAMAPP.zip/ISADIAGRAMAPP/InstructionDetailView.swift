import SwiftUI

struct InstructionDetailView: View {
    let instruction: Instruction

    private var accentColor: Color {
        instruction.arch == .arm ? .blue : Color(red: 0.96, green: 0.65, blue: 0.14)
    }

    private var bgColor: Color {
        instruction.arch == .arm
            ? Color.blue.opacity(0.07)
            : Color(red: 1.0, green: 0.95, blue: 0.8)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            // Header badges
            HStack(spacing: 8) {
                BadgeView(label: instruction.arch.rawValue, color: accentColor)
                BadgeView(
                    label: instruction.arch == .arm ? "Single Core" : "Multi Core",
                    color: accentColor.opacity(0.6)
                )
            }

            // Mnemonic + operands
            HStack(alignment: .firstTextBaseline, spacing: 6) {
                Text(instruction.mnemonic)
                    .font(.system(.title, design: .monospaced).bold())
                    .foregroundColor(.primary)
                if !instruction.operands.isEmpty {
                    Text(instruction.operands)
                        .font(.system(.title2, design: .monospaced))
                        .foregroundColor(.secondary)
                }
            }

            // Short description
            Text(instruction.description)
                .font(.subheadline)
                .foregroundColor(.secondary)

            Divider()

            // Full detail
            Text(instruction.detail)
                .font(.body)
                .fixedSize(horizontal: false, vertical: true)

            Divider()

            // Encoding
            HStack(spacing: 8) {
                Text("Encoding:")
                    .font(.caption)
                    .foregroundColor(.secondary)
                Text(instruction.encoding)
                    .font(.system(.caption, design: .monospaced))
                    .padding(.horizontal, 8)
                    .padding(.vertical, 3)
                    .background(accentColor.opacity(0.12))
                    .cornerRadius(6)
                    .foregroundColor(accentColor)
            }
        }
        .padding(20)
        .background(bgColor)
        .clipShape(RoundedRectangle(cornerRadius: 14))
        .overlay(
            RoundedRectangle(cornerRadius: 14)
                .strokeBorder(accentColor.opacity(0.4), lineWidth: 1.5)
        )
    }
}

struct BadgeView: View {
    let label: String
    let color: Color

    var body: some View {
        Text(label)
            .font(.caption.bold())
            .padding(.horizontal, 9)
            .padding(.vertical, 4)
            .background(color)
            .foregroundColor(.white)
            .clipShape(Capsule())
    }
}
