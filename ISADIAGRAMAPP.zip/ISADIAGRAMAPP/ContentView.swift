import SwiftUI

struct ContentView: View {
    @State private var selectedInstruction: Instruction? = nil

    var body: some View {
        HSplitView {
            // Left panel: diagram + tables
            ScrollView {
                VStack(alignment: .leading, spacing: 28) {
                    titleSection
                    diagramSection
                    legendRow
                    tablesSection
                }
                .padding(24)
            }
            .frame(minWidth: 600)

            // Right panel: detail
            VStack(spacing: 0) {
                if let ins = selectedInstruction {
                    ScrollView {
                        InstructionDetailView(instruction: ins)
                            .padding(20)
                    }
                    .transition(.opacity.combined(with: .move(edge: .trailing)))
                } else {
                    emptyDetailPlaceholder
                }
            }
            .frame(minWidth: 280, idealWidth: 320, maxWidth: 380)
            .background(Color(NSColor.windowBackgroundColor))
        }
        .navigationTitle("ISA Diagram")
    }

    // MARK: - Title

    private var titleSection: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("Instruction Set Architecture")
                .font(.largeTitle.bold())
            Text("Single-core ARM AArch64  ·  Blue lane     |     Multi-core x86-64  ·  Yellow hexagons")
                .font(.subheadline)
                .foregroundColor(.secondary)
        }
    }

    // MARK: - Diagram

    private var diagramSection: some View {
        VStack(spacing: 0) {
            // x86 hex labels (top)
            HStack(spacing: 0) {
                ForEach(x86Cores) { core in
                    Text("Multicore Lane")
                        .font(.caption2.bold())
                        .foregroundColor(Color(red: 0.8, green: 0.5, blue: 0.0))
                        .frame(maxWidth: .infinity)
                }
            }
            .padding(.bottom, 4)

            ZStack(alignment: .center) {
                // ARM blue lane
                GeometryReader { geo in
                    ARMLaneView(instructions: armInstructions, selected: $selectedInstruction)
                        .frame(height: 34)
                        .position(x: geo.size.width / 2, y: geo.size.height / 2)
                }
                .frame(height: 34)

                // x86 hexagons overlaid on the lane
                HStack(spacing: 28) {
                    ForEach(x86Cores) { core in
                        X86HexView(core: core, selected: $selectedInstruction)
                    }
                }
            }
            .frame(height: 200)

            // x86 hex labels (bottom)
            HStack(spacing: 0) {
                ForEach(x86Cores) { core in
                    Text("Multicore Lane")
                        .font(.caption2.bold())
                        .foregroundColor(Color(red: 0.8, green: 0.5, blue: 0.0))
                        .frame(maxWidth: .infinity)
                }
            }
            .padding(.top, 4)
        }
        .padding(16)
        .background(Color(NSColor.controlBackgroundColor))
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .strokeBorder(Color.secondary.opacity(0.15), lineWidth: 1)
        )
    }

    // MARK: - Legend

    private var legendRow: some View {
        HStack(spacing: 20) {
            HStack(spacing: 6) {
                Circle().fill(.blue).frame(width: 12, height: 12)
                Text("ARM AArch64 · Single Core")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            HStack(spacing: 6) {
                Circle()
                    .fill(Color(red: 0.96, green: 0.65, blue: 0.14))
                    .frame(width: 12, height: 12)
                Text("x86-64 · Multi Core (3 Cores)")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            Spacer()
            if selectedInstruction != nil {
                Button("Clear selection") {
                    withAnimation { selectedInstruction = nil }
                }
                .buttonStyle(.borderless)
                .font(.caption)
                .foregroundColor(.blue)
            }
        }
    }

    // MARK: - Tables

    private var tablesSection: some View {
        HStack(alignment: .top, spacing: 20) {
            // ARM table
            InstructionTableView(
                instructions: armInstructions,
                arch: .arm,
                selected: $selectedInstruction
            )
            .frame(maxWidth: .infinity)

            // x86 table (all cores combined)
            InstructionTableView(
                instructions: x86Cores.flatMap { $0.instructions },
                arch: .x86,
                selected: $selectedInstruction
            )
            .frame(maxWidth: .infinity)
        }
    }

    // MARK: - Empty state

    private var emptyDetailPlaceholder: some View {
        VStack(spacing: 12) {
            Spacer()
            Image(systemName: "cpu")
                .font(.system(size: 40))
                .foregroundColor(.secondary.opacity(0.4))
            Text("Select an instruction")
                .font(.headline)
                .foregroundColor(.secondary)
            Text("Click any node in the diagram\nor any row in the tables below.")
                .font(.caption)
                .multilineTextAlignment(.center)
                .foregroundColor(.secondary.opacity(0.7))
            Spacer()
        }
        .padding()
    }
}

#Preview {
    ContentView()
        .frame(width: 1000, height: 750)
}
