import SwiftUI

struct X86HexView: View {
    let core: X86Core
    @Binding var selected: Instruction?

    private let hexWidth: CGFloat  = 200
    private let hexHeight: CGFloat = 174
    private let nodeRadius: CGFloat = 22

    var body: some View {
        VStack(spacing: 4) {
            Text("Multicore Lane")
                .font(.caption2.bold())
                .foregroundColor(Color(red: 0.8, green: 0.5, blue: 0.0))

            ZStack {
                // Hexagon border
                HexagonShape()
                    .stroke(Color(red: 0.96, green: 0.65, blue: 0.14), lineWidth: 3.5)
                    .frame(width: hexWidth, height: hexHeight)

                // Semi-transparent fill
                HexagonShape()
                    .fill(Color(red: 1.0, green: 0.97, blue: 0.88).opacity(0.6))
                    .frame(width: hexWidth, height: hexHeight)

                // Center label
                Text("x86-64\nCore \(core.id)")
                    .font(.system(size: 10, weight: .bold))
                    .multilineTextAlignment(.center)
                    .foregroundColor(Color(red: 0.57, green: 0.33, blue: 0.0))

                // Instruction nodes placed around a circle inside the hex
                let count = core.instructions.count
                ForEach(Array(core.instructions.enumerated()), id: \.element.id) { idx, ins in
                    let angle = (Double(idx) / Double(count)) * 2 * .pi - .pi / 2
                    let r: CGFloat = 60
                    let cx = CGFloat(cos(angle)) * r
                    let cy = CGFloat(sin(angle)) * r
                    let isSelected = selected == ins

                    Button {
                        withAnimation(.spring(response: 0.3)) {
                            selected = (selected == ins) ? nil : ins
                        }
                    } label: {
                        ZStack {
                            Circle()
                                .fill(isSelected
                                      ? Color(red: 0.96, green: 0.65, blue: 0.14)
                                      : Color(red: 1.0, green: 0.97, blue: 0.86))
                                .frame(width: nodeRadius * 2, height: nodeRadius * 2)
                                .overlay(
                                    Circle()
                                        .strokeBorder(
                                            Color(red: 0.85, green: 0.53, blue: 0.0),
                                            lineWidth: isSelected ? 2.5 : 1.5
                                        )
                                )
                                .shadow(color: Color(red: 0.96, green: 0.65, blue: 0.14).opacity(isSelected ? 0.6 : 0.15),
                                        radius: isSelected ? 8 : 2)

                            Text(ins.mnemonic)
                                .font(.system(size: 8, weight: .bold, design: .monospaced))
                                .foregroundColor(Color(red: 0.47, green: 0.22, blue: 0.0))
                        }
                    }
                    .buttonStyle(.plain)
                    .offset(x: cx, y: cy)
                }
            }
            .frame(width: hexWidth, height: hexHeight)

            Text("Multicore Lane")
                .font(.caption2.bold())
                .foregroundColor(Color(red: 0.8, green: 0.5, blue: 0.0))
        }
    }
}
