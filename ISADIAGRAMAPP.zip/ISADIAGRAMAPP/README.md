# ISA Diagram — Native SwiftUI App

A pure native SwiftUI application visualizing Single-core ARM AArch64 and Multi-core x86-64 instruction set architecture, matching the reference diagram (blue single-core lane + 3 yellow hexagonal multi-core lanes).

## How to open in Xcode

1. Download / clone this folder to your Mac.
2. Open **Xcode** (requires Xcode 15 or later).
3. Choose **File → Open** and select the `ISADiagramApp` folder (the one containing `Package.swift`).
4. Xcode will resolve the Swift Package automatically.
5. Press **⌘R** to build and run on macOS.

> For iOS: change the run destination to any iPhone simulator in the Xcode toolbar, then press ⌘R.

## File structure

```
ISADiagramApp/
├── Package.swift                   ← Swift Package manifest
└── ISADiagramApp/
    ├── ISADiagramApp.swift         ← @main App entry point
    ├── Models.swift                ← Instruction & core data models
    ├── ContentView.swift           ← Root layout (split view)
    ├── ARMLaneView.swift           ← Blue single-core ARM lane
    ├── X86HexView.swift            ← Yellow hexagonal x86-64 cores
    ├── HexagonShape.swift          ← Custom SwiftUI Shape for hexagon
    ├── InstructionDetailView.swift ← Right-panel detail card
    └── InstructionTableView.swift  ← Sortable instruction tables
```

## Features

- Blue horizontal lane = ARM AArch64 single-core (10 instructions: MOV, ADD, SUB, MUL, LDR, STR, BL, RET, CMP, B.EQ)
- 3 yellow hexagons = x86-64 multi-core, one per core (4 instructions each: 12 total)
- Click any node or table row to see full encoding + description
- macOS split-view layout; works on iOS too
