import Foundation

enum Architecture: String, CaseIterable {
    case arm = "ARM AArch64"
    case x86 = "x86-64"
}

enum CoreType {
    case single
    case multi(Int)
}

struct Instruction: Identifiable, Equatable {
    let id = UUID()
    let mnemonic: String
    let operands: String
    let encoding: String
    let description: String
    let detail: String
    let arch: Architecture

    static func == (lhs: Instruction, rhs: Instruction) -> Bool {
        lhs.id == rhs.id
    }
}

struct X86Core: Identifiable {
    let id: Int
    let instructions: [Instruction]
}

// MARK: - ARM AArch64 Instructions (Single Core)

let armInstructions: [Instruction] = [
    Instruction(
        mnemonic: "MOV",
        operands: "Xd, Xn",
        encoding: "0xAA0003E0",
        description: "Move register value to destination.",
        detail: "Copies the 64-bit value from source register Xn into destination register Xd. No flags are set.",
        arch: .arm
    ),
    Instruction(
        mnemonic: "ADD",
        operands: "Xd, Xn, Xm",
        encoding: "0x8B000000",
        description: "Add two registers, store result.",
        detail: "Computes Xd = Xn + Xm. Operates on 64-bit general purpose registers. Does not set condition flags (use ADDS for that).",
        arch: .arm
    ),
    Instruction(
        mnemonic: "SUB",
        operands: "Xd, Xn, Xm",
        encoding: "0xCB000000",
        description: "Subtract Xm from Xn, store in Xd.",
        detail: "Computes Xd = Xn − Xm. Equivalent to ADD with negated operand. Use SUBS to update flags.",
        arch: .arm
    ),
    Instruction(
        mnemonic: "MUL",
        operands: "Xd, Xn, Xm",
        encoding: "0x9B007C00",
        description: "Multiply two registers.",
        detail: "Computes Xd = Xn × Xm (lower 64 bits). For the full 128-bit product use UMULH or SMULH.",
        arch: .arm
    ),
    Instruction(
        mnemonic: "LDR",
        operands: "Xt, [Xn]",
        encoding: "0xF9400000",
        description: "Load 64-bit value from memory.",
        detail: "Loads the 64-bit doubleword at the memory address in Xn into register Xt. Uses base register addressing.",
        arch: .arm
    ),
    Instruction(
        mnemonic: "STR",
        operands: "Xt, [Xn]",
        encoding: "0xF9000000",
        description: "Store 64-bit register to memory.",
        detail: "Stores the 64-bit value in Xt to the memory address held in Xn.",
        arch: .arm
    ),
    Instruction(
        mnemonic: "BL",
        operands: "label",
        encoding: "0x94000000",
        description: "Branch with link (subroutine call).",
        detail: "Branches to the PC-relative offset label and saves the return address in the Link Register (X30/LR).",
        arch: .arm
    ),
    Instruction(
        mnemonic: "RET",
        operands: "",
        encoding: "0xD65F03C0",
        description: "Return from subroutine.",
        detail: "Branches unconditionally to the address stored in LR (X30). This is the standard function return on AArch64.",
        arch: .arm
    ),
    Instruction(
        mnemonic: "CMP",
        operands: "Xn, Xm",
        encoding: "0xEB00001F",
        description: "Compare two registers, set flags.",
        detail: "Performs Xn − Xm and updates the condition flags (NZCV). The result is discarded. Equivalent to SUBS XZR, Xn, Xm.",
        arch: .arm
    ),
    Instruction(
        mnemonic: "B.EQ",
        operands: "label",
        encoding: "0x54000000",
        description: "Branch if equal (Z flag set).",
        detail: "Conditionally branches to label if the Z (zero) flag is set, typically following a CMP or SUBS instruction.",
        arch: .arm
    ),
]

// MARK: - x86-64 Instructions (Multi Core)

let x86Cores: [X86Core] = [
    X86Core(id: 1, instructions: [
        Instruction(
            mnemonic: "MOV",
            operands: "rax, rbx",
            encoding: "48 89 D8",
            description: "Move 64-bit register to register.",
            detail: "Copies the 64-bit value in RBX into RAX. REX.W prefix (0x48) selects 64-bit operand size.",
            arch: .x86
        ),
        Instruction(
            mnemonic: "ADD",
            operands: "rax, rcx",
            encoding: "48 01 C8",
            description: "Add RCX to RAX, update flags.",
            detail: "Computes RAX = RAX + RCX and updates CF, OF, SF, ZF, AF, PF flags. 64-bit operation via REX.W.",
            arch: .x86
        ),
        Instruction(
            mnemonic: "PUSH",
            operands: "rbp",
            encoding: "55",
            description: "Push RBP onto the stack.",
            detail: "Decrements RSP by 8 and stores RBP at the new stack top. Standard function prologue first instruction.",
            arch: .x86
        ),
        Instruction(
            mnemonic: "POP",
            operands: "rbp",
            encoding: "5D",
            description: "Pop stack top into RBP.",
            detail: "Loads the 64-bit value from [RSP] into RBP, then increments RSP by 8. Standard function epilogue.",
            arch: .x86
        ),
    ]),
    X86Core(id: 2, instructions: [
        Instruction(
            mnemonic: "SUB",
            operands: "rsp, 0x20",
            encoding: "48 83 EC 20",
            description: "Allocate 32 bytes of stack space.",
            detail: "Subtracts immediate 0x20 (32) from RSP, creating a local stack frame. Required for shadow space on Windows x64 ABI.",
            arch: .x86
        ),
        Instruction(
            mnemonic: "IMUL",
            operands: "rax, rbx",
            encoding: "48 0F AF C3",
            description: "Signed 64-bit multiply.",
            detail: "Computes the signed product RAX = RAX × RBX (lower 64 bits). OF and CF are set if the result overflows 64 bits.",
            arch: .x86
        ),
        Instruction(
            mnemonic: "CALL",
            operands: "func",
            encoding: "E8 xx xx xx xx",
            description: "Call near procedure.",
            detail: "Pushes the return address (next RIP) onto the stack then jumps to the target. The 4-byte displacement is PC-relative.",
            arch: .x86
        ),
        Instruction(
            mnemonic: "LEA",
            operands: "rax, [rbx+8]",
            encoding: "48 8D 43 08",
            description: "Load effective address.",
            detail: "Computes the address rbx+8 and stores it in RAX without accessing memory. Useful for pointer arithmetic.",
            arch: .x86
        ),
    ]),
    X86Core(id: 3, instructions: [
        Instruction(
            mnemonic: "XOR",
            operands: "rax, rax",
            encoding: "48 31 C0",
            description: "Zero a register efficiently.",
            detail: "XORs RAX with itself, producing zero. Preferred zero idiom on x86-64 as it is smaller and faster than MOV RAX, 0.",
            arch: .x86
        ),
        Instruction(
            mnemonic: "CMP",
            operands: "rax, 0",
            encoding: "48 83 F8 00",
            description: "Compare RAX to zero, set flags.",
            detail: "Subtracts 0 from RAX and sets flags without storing the result. Commonly precedes JE/JNE conditional jumps.",
            arch: .x86
        ),
        Instruction(
            mnemonic: "JNE",
            operands: "label",
            encoding: "75 xx",
            description: "Jump if not equal (ZF = 0).",
            detail: "Short jump to an 8-bit signed relative offset if the Zero Flag is clear (result was not zero).",
            arch: .x86
        ),
        Instruction(
            mnemonic: "RET",
            operands: "",
            encoding: "C3",
            description: "Near return from procedure.",
            detail: "Pops the return address from the stack into RIP and resumes execution there. Counterpart to CALL.",
            arch: .x86
        ),
    ]),
]
