// swift-tools-version:5.9

import PackageDescription

let package = Package(
    name: "HybridSimulatorSPM",
    platforms: [
        .macOS(.v13) // Specify macOS 13 or later
    ],
    products: [
        .executable(name: "HybridSimulatorApp", targets: ["HybridSimulatorApp"])
    ],
    targets: [
        .executableTarget(
            name: "HybridSimulatorApp",
            dependencies: [],
            resources: [
                .process("hybrid_simulator.py") // Include Python script as a resource
            ]
        )
    ]
)
