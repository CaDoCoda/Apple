import Foundation

// --- Setup ---
// In a real Xcode project, these would be bundled resources or user-defined paths.
let pythonPath = "/usr/bin/python3"

// This path assumes hybrid_simulator.py is copied into the app's bundle resources
// and is accessible relative to the executable.
let scriptPath = Bundle.module.path(forResource: "hybrid_simulator", ofType: "py") ?? ""

// Ensure the script path is valid
if scriptPath.isEmpty {
    fatalError("Error: hybrid_simulator.py not found in application bundle.")
}

let client = HybridSimulatorClient(pythonExecutablePath: pythonPath, simulatorScriptPath: scriptPath)

print("--- Hybrid ARM-x86 Architecture Simulator: Swift Interface ---")

Task {
    do {
        // 1. Run the built-in demo
        print("\n[Swift] Running Simulator Demo...")
        let demoResults = try await client.runDemo()
        print("[Swift] Demo Results:")
        for result in demoResults {
            print("  Task \(result.taskId): \(result.status), Result: \(result.result ?? -1)")
        }

        // 2. Dispatch a custom task
        print("\n[Swift] Dispatching Custom Task...")
        let customData: [UInt32] = [100, 200, 300, 400]
        let taskId = try await client.dispatchTask(inputData: customData)
        print("[Swift] Custom Task Dispatched (ID: \(taskId))")

        // 3. Poll for the result
        print("[Swift] Polling for result...")
        var completed = false
        for _ in 0..<10 {
            let result = try await client.getTaskResult(taskId: taskId)
            if result.status == "Completed" {
                print("[Swift] Custom Task Result: \(result.result ?? -1)")
                completed = true
                break
            }
            try await Task.sleep(nanoseconds: 200_000_000) // 200ms
        }
        
        if !completed {
            print("[Swift] Custom Task timed out.")
        }

    } catch {
        print("\n[Swift] Error: \(error)")
    }
    
    print("\n--- Simulation Complete ---")
    exit(0)
}

// Keep the main thread alive for the async Task
RunLoop.main.run()
