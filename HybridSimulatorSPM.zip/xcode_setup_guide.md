# Guide for Setting Up and Running the Hybrid Simulator SPM Project on macOS

This guide provides step-by-step instructions to set up and run the Swift-based client for the Hybrid ARM-x86 Simulator using Swift Package Manager (SPM) within Xcode on macOS.

## 1. Prerequisites

Before you begin, ensure you have the following installed:

*   **Xcode:** Download and install Xcode from the Mac App Store. This includes the Swift compiler and necessary development tools.
*   **Python 3:** macOS typically comes with Python 3 pre-installed. You can verify by running `python3 --version` in your Terminal. If not installed, download it from [python.org](https://www.python.org/downloads/).
*   **Project Files:** Ensure you have the following files and directory structure:
    ```
    HybridSimulatorSPM/
    ├── Package.swift
    ├── Sources/
    │   └── HybridSimulatorApp/
    │       ├── main.swift
    │       └── HybridSimulatorClient.swift
    └── Resources/
        └── hybrid_simulator.py
    ```

## 2. Open the Project in Xcode

Unlike traditional Xcode projects, SPM projects are opened directly via their `Package.swift` file.

1.  **Locate `Package.swift`:** Navigate to the `HybridSimulatorSPM` directory that contains the `Package.swift` file.
2.  **Open with Xcode:** Right-click on `Package.swift` and select `Open With > Xcode`. Alternatively, you can open Xcode, go to `File > Open...`, and select the `Package.swift` file.

Xcode will automatically generate the project structure, resolve dependencies, and prepare the project for building.

## 3. Configure Python Executable Path in Swift

In `Sources/HybridSimulatorApp/main.swift`, you need to ensure the `pythonPath` variable correctly points to your Python 3 executable. The `scriptPath` variable is already configured to locate the `hybrid_simulator.py` file as an SPM resource.

```swift
// --- Setup ---
let pythonPath = "/usr/bin/python3" // Verify this path on your system

// This path assumes hybrid_simulator.py is copied into the app's bundle resources
// and is accessible relative to the executable.
let scriptPath = Bundle.module.path(forResource: "hybrid_simulator", ofType: "py") ?? ""

// Ensure the script path is valid
if scriptPath.isEmpty {
    fatalError("Error: hybrid_simulator.py not found in application bundle.")
}

let client = HybridSimulatorClient(pythonExecutablePath: pythonPath, simulatorScriptPath: scriptPath)
```

**Important:** The `pythonPath` might vary depending on your system or Python installation. Common paths include `/usr/bin/python3`, `/usr/local/bin/python3`, or paths within a virtual environment. You can find your Python 3 path by running `which python3` in your Terminal.

## 4. Build and Run the Project

1.  **Select Scheme:** In Xcode, ensure your `HybridSimulatorApp` scheme is selected (usually next to the Play/Stop buttons).
2.  **Build:** Go to `Product > Build` or press `Cmd + B`.
3.  **Run:** Go to `Product > Run` or press `Cmd + R`.

Xcode will compile and run your Swift application. You should see output in Xcode's console demonstrating the Python simulator's task dispatch and result retrieval.

## 5. Troubleshooting

*   **`pythonScriptNotFound` Error:** Ensure `hybrid_simulator.py` is correctly placed in the `Resources` directory at the root of your SPM package and that `Bundle.module.path` is correctly used in `main.swift`.
*   **`executionFailed` Error:**
    *   Verify `pythonPath` in `main.swift` points to a valid Python 3 executable.
    *   Check Xcode's console for any `stderr` output from the Python script, which might indicate Python-specific errors (e.g., syntax errors, missing modules).
*   **`jsonParsingFailed` or `invalidOutput` Error:** Ensure the Python script is outputting valid JSON to `stdout` and that the Swift `TaskResult` struct matches the JSON structure.

This SPM setup allows your Swift application to leverage the Python simulator as a backend process, demonstrating a practical approach to integrating different language environments for complex system simulations.
